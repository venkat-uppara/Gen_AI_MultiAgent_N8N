import streamlit as st
import requests

API_URL = "http://localhost:5000/chat"

st.set_page_config(page_title="LangChain Chat App")
st.title("💬 GenAI Chat App (LangChain + Flask)")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

user_input = st.chat_input("Ask something...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.write(user_input)

    response = requests.post(
        API_URL,
        json={
            "input": user_input,
            "session_id": "streamlit_user"
        }
    )

    if response.status_code == 200:
        bot_reply = response.json().get("response", "")
    else:
        bot_reply = "Error from API"

    st.session_state.messages.append({"role": "assistant", "content": bot_reply})
    with st.chat_message("assistant"):
        st.write(bot_reply)
