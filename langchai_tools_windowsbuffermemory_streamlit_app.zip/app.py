import os
from flask import Flask, request, jsonify
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from langchain_classic.agents import AgentExecutor, create_react_agent
from langchain_community.agent_toolkits.load_tools import load_tools
from langchain_core.prompts import PromptTemplate
from langchain_core.messages import trim_messages, HumanMessage, AIMessage

# --------------------------------------------------
# Load ENV
# --------------------------------------------------
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
SERPAPI_API_KEY = os.getenv("SERPAPI_API_KEY")

# --------------------------------------------------
# LLM
# --------------------------------------------------
llm = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)

# --------------------------------------------------
# Tools
# --------------------------------------------------
tools = load_tools(["serpapi", "llm-math"], llm=llm)

# --------------------------------------------------
# ✅ FIXED PROMPT (ReAct compliant)
# --------------------------------------------------
react_prompt = PromptTemplate.from_template(
    """Answer the following questions as best you can.

You have access to the following tools:
{tools}

Use the following format:

Question: the input question
Thought: think about what to do
Action: one of [{tool_names}]
Action Input: input to the tool
Observation: result of the tool
... (this can repeat multiple times)
Thought: I now know the final answer
Final Answer: the final answer

Previous conversation:
{chat_history}

Question: {input}
Thought:{agent_scratchpad}
"""
)

# --------------------------------------------------
# Agent
# --------------------------------------------------
agent = create_react_agent(llm, tools, react_prompt)

agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True
)

# --------------------------------------------------
# 🔥 Modern Memory (Token-aware)
# --------------------------------------------------
session_store = {}

trimmer = trim_messages(
    max_tokens=200000,
    strategy="last",
    token_counter=llm,
    include_system=True
)

def get_history(session_id):
    if session_id not in session_store:
        session_store[session_id] = []
    return session_store[session_id]

# --------------------------------------------------
# Flask
# --------------------------------------------------
app = Flask(__name__)

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        user_input = data["input"]
        session_id = data.get("session_id", "default")

        history = get_history(session_id)

        # Add user message
        history.append(HumanMessage(content=user_input))

        # Trim memory
        trimmed_history = trimmer.invoke(history)

        # Convert history → string
        chat_history_str = "\n".join(
            [f"{m.type}: {m.content}" for m in trimmed_history]
        )

        # Agent call
        result = agent_executor.invoke({
            "input": user_input,
            "chat_history": chat_history_str
        })

        output = result["output"]

        # Save AI response
        history.append(AIMessage(content=output))

        return jsonify({"response": output})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)