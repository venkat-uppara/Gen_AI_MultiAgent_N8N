output "alb_dns_name" {
  description = "DNS name of the public ALB fronting n8n."
  value       = aws_lb.this.dns_name
}

output "n8n_base_url" {
  description = "Base URL for the n8n UI and webhook endpoints."
  value       = local.n8n_base_url
}

output "native_health_url" {
  description = "n8n native health endpoint."
  value       = "${local.n8n_base_url}/healthz"
}

output "rag_health_url" {
  description = "RAG workflow health endpoint."
  value       = "${local.n8n_base_url}/webhook/rag/health"
}

output "cluster_name" {
  description = "ECS cluster name."
  value       = aws_ecs_cluster.this.name
}

output "service_name" {
  description = "ECS service name."
  value       = aws_ecs_service.this.name
}

output "rds_endpoint" {
  description = "RDS PostgreSQL endpoint."
  value       = aws_db_instance.this.address
}

output "opensearch_endpoint" {
  description = "OpenSearch endpoint used by the workflows."
  value       = local.opensearch_endpoint
}

output "opensearch_index_name" {
  description = "OpenSearch index name used for vector storage."
  value       = var.opensearch_index_name
}

output "post_apply_checklist" {
  description = "Short checklist for the remaining manual steps after terraform apply."
  value       = <<-EOT
  1. Open ${local.n8n_base_url} in your browser.
  2. Complete the first n8n owner setup.
  3. Import the workflow files from AWS_PAAS/workflows:
     - 01-document-ingestion.json
     - 02-rag-query.json
     - 03-health-check.json
  4. Activate all three workflows.
  5. Run the first ingest or the full test suite. The first successful ingest creates the ${var.opensearch_index_name} index from inside n8n.
  6. Run:
     python .\scripts\test_api.py --base-url ${local.n8n_base_url} --test all
  EOT
}
