# Leave this as-is unless you want a different AWS region.
aws_region = "us-east-1"

# These names are used in AWS resource naming.
project_name = "n8n-rag"
environment  = "dev"

# Your current public IP address. Update this and re-run terraform apply if your IP changes.
allowed_cidr_blocks = [
  "XXX.XXX.XX.XXX/32"
]

db_password                = "XXXXXXX"
opensearch_master_password = "XXXXXXX"

# Replace this with your real OpenAI API key before terraform apply.
openai_api_key = "sk-proj-w6Dza6fuiaXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"

# Leave this as-is unless you want a different n8n image tag.
n8n_image = "n8nio/n8n:latest"

# Optional tags for AWS resources.
tags = {
  Owner = "<GIVE YOUR NAME HERE>"
}