variable "aws_region" {
  description = "AWS region for the deployment."
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Short project name used in resource naming."
  type        = string
  default     = "n8n-rag"
}

variable "environment" {
  description = "Environment name used in resource naming."
  type        = string
  default     = "dev"
}

variable "vpc_cidr" {
  description = "CIDR block for the dedicated VPC."
  type        = string
  default     = "10.42.0.0/16"
}

variable "allowed_cidr_blocks" {
  description = "CIDR blocks allowed to reach the ALB over HTTP."
  type        = list(string)

  validation {
    condition     = length(var.allowed_cidr_blocks) > 0
    error_message = "Provide at least one CIDR block in allowed_cidr_blocks."
  }
}

variable "openai_api_key" {
  description = "OpenAI API key stored in Secrets Manager and injected into the ECS task."
  type        = string
  sensitive   = true

  validation {
    condition     = length(trimspace(var.openai_api_key)) > 0
    error_message = "openai_api_key cannot be empty."
  }
}

variable "n8n_image" {
  description = "n8n container image for ECS."
  type        = string
  default     = "n8nio/n8n:latest"
}

variable "container_port" {
  description = "Port exposed by the n8n container."
  type        = number
  default     = 5678
}

variable "ecs_cpu" {
  description = "Fargate task CPU units."
  type        = number
  default     = 1024
}

variable "ecs_memory" {
  description = "Fargate task memory in MiB."
  type        = number
  default     = 2048
}

variable "desired_count" {
  description = "Desired ECS task count."
  type        = number
  default     = 1
}

variable "db_name" {
  description = "Database name for n8n."
  type        = string
  default     = "n8n"
}

variable "db_username" {
  description = "Database username for n8n."
  type        = string
  default     = "n8n"
}

variable "db_password" {
  description = "Optional override for the RDS master password. Leave empty to auto-generate a compatible password."
  type        = string
  default     = ""
  sensitive   = true

  validation {
    condition = trimspace(var.db_password) == "" || (
      length(var.db_password) >= 8 &&
      length(var.db_password) <= 128 &&
      can(regex("^[!-~]+$", var.db_password)) &&
      length(regexall("[/@\"]", var.db_password)) == 0
    )
    error_message = "db_password must be 8-128 printable non-space ASCII characters and cannot contain /, @, or \"."
  }
}

variable "db_instance_class" {
  description = "RDS instance class."
  type        = string
  default     = "db.t3.micro"
}

variable "db_allocated_storage" {
  description = "RDS storage in GiB."
  type        = number
  default     = 20
}

variable "opensearch_domain_name" {
  description = "Optional override for the OpenSearch domain name. Leave empty to derive it from project and environment."
  type        = string
  default     = ""
}

variable "opensearch_engine_version" {
  description = "OpenSearch engine version."
  type        = string
  default     = "OpenSearch_2.11"
}

variable "opensearch_instance_type" {
  description = "OpenSearch data node instance type."
  type        = string
  default     = "t3.small.search"
}

variable "opensearch_volume_size" {
  description = "OpenSearch EBS volume size in GiB."
  type        = number
  default     = 20
}

variable "opensearch_master_username" {
  description = "Master username for the OpenSearch internal user database."
  type        = string
  default     = "admin"
}

variable "opensearch_master_password" {
  description = "Optional override for the OpenSearch internal user database master password. Leave empty to auto-generate one."
  type        = string
  default     = ""
  sensitive   = true
}

variable "opensearch_index_name" {
  description = "Vector index name used by the workflows."
  type        = string
  default     = "rag-documents"
}

variable "n8n_encryption_key" {
  description = "Optional override for the n8n encryption key stored in Secrets Manager. Leave empty to auto-generate one."
  type        = string
  default     = ""
  sensitive   = true
}

variable "openai_llm_model" {
  description = "OpenAI chat model used by the query workflow."
  type        = string
  default     = "gpt-4o"
}

variable "openai_embedding_model" {
  description = "OpenAI embedding model used by ingest and query."
  type        = string
  default     = "text-embedding-3-large"
}

variable "openai_embedding_dimensions" {
  description = "Embedding vector dimension used for OpenSearch."
  type        = number
  default     = 1024
}

variable "tool_web_search_enabled" {
  description = "Enable web search helper behavior in the workflow."
  type        = bool
  default     = true
}

variable "tool_calculator_enabled" {
  description = "Enable calculator helper behavior in the workflow."
  type        = bool
  default     = true
}

variable "tool_datetime_enabled" {
  description = "Enable datetime helper behavior in the workflow."
  type        = bool
  default     = true
}

variable "log_retention_in_days" {
  description = "CloudWatch log retention for the ECS log group."
  type        = number
  default     = 14
}

variable "tags" {
  description = "Extra tags applied to created resources."
  type        = map(string)
  default     = {}
}
