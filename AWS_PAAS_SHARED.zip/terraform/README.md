# AWS_PAAS Terraform Pack

This folder provisions the AWS infrastructure for the `AWS_PAAS` n8n deployment with Terraform.

## Goal

Keep the manual steps on your side minimal.

## Inputs You Must Provide

You only need to set these values in `terraform.tfvars` for the first working deployment:

- `aws_region`
- `allowed_cidr_blocks`
- `openai_api_key`

Everything else has a default intended for a first ECS/Fargate deployment without a custom domain.

## What This Terraform Pack Creates

- VPC and subnets
- ALB
- ECS cluster and Fargate service
- RDS PostgreSQL
- Amazon OpenSearch Service
- Secrets Manager secrets
- CloudWatch log group
- IAM roles
- the runtime configuration needed for n8n to create the `rag-documents` OpenSearch index on first ingest

## What Terraform Does Not Do

After apply, you still need to:

1. open the n8n URL from Terraform output
2. complete first owner setup
3. import the three workflow JSON files from `..\workflows`
4. activate the workflows
5. run `..\scripts\test_api.py`

## Commands

Initialize:

```powershell
terraform init
```

Review:

```powershell
terraform plan
```

Create:

```powershell
terraform apply
```

Show the n8n URL:

```powershell
terraform output -raw n8n_base_url
```

Destroy:

```powershell
terraform destroy
```

## Files

- `versions.tf`
  - Terraform and provider requirements
- `variables.tf`
  - all tunable values and defaults
- `main.tf`
  - the AWS resources for the ECS/Fargate deployment
- `outputs.tf`
  - URLs, names, and the post-apply checklist output
- `terraform.tfvars.example`
  - the smallest useful input file to copy and edit

## Practical Time Expectation

The longest part is AWS creating RDS and OpenSearch.

Expect the full apply to take significantly longer than the manual browser work that follows it.
