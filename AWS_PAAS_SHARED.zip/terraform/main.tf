data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_caller_identity" "current" {}

data "aws_iam_policy_document" "ecs_task_assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}

locals {
  name_prefix                = "${var.project_name}-${var.environment}"
  short_prefix               = substr(local.name_prefix, 0, 20)
  alb_name                   = "${local.short_prefix}-alb"
  target_group_name          = "${local.short_prefix}-tg"
  cluster_name               = "${local.name_prefix}-cluster"
  service_name               = "${local.name_prefix}-service"
  log_group_name             = "/ecs/${local.name_prefix}"
  public_subnet_cidrs        = [cidrsubnet(var.vpc_cidr, 8, 0), cidrsubnet(var.vpc_cidr, 8, 1)]
  opensearch_domain_name     = trimspace(var.opensearch_domain_name) != "" ? var.opensearch_domain_name : "${local.short_prefix}-os"
  db_password                = trimspace(var.db_password) != "" ? var.db_password : random_password.db[0].result
  opensearch_master_password = trimspace(var.opensearch_master_password) != "" ? var.opensearch_master_password : random_password.opensearch_master[0].result
  n8n_encryption_key_value   = trimspace(var.n8n_encryption_key) != "" ? var.n8n_encryption_key : random_password.n8n_encryption_key[0].result
  opensearch_endpoint        = "https://${aws_opensearch_domain.this.endpoint}"
  opensearch_auth_header     = "Basic ${base64encode("${var.opensearch_master_username}:${local.opensearch_master_password}")}"
  n8n_base_url               = "http://${aws_lb.this.dns_name}"
  common_tags = merge({
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "terraform"
    Stack       = "AWS_PAAS"
  }, var.tags)
}

resource "random_password" "db" {
  count            = trimspace(var.db_password) == "" ? 1 : 0
  length           = 24
  special          = true
  override_special = "!#%^*_-+="
}

resource "random_password" "opensearch_master" {
  count            = trimspace(var.opensearch_master_password) == "" ? 1 : 0
  length           = 24
  special          = true
  override_special = "!#%^*_-+="
}

resource "random_password" "n8n_encryption_key" {
  count   = trimspace(var.n8n_encryption_key) == "" ? 1 : 0
  length  = 64
  special = false
}

resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-vpc"
  })
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-igw"
  })
}

resource "aws_subnet" "public" {
  count = 2

  vpc_id                  = aws_vpc.this.id
  cidr_block              = local.public_subnet_cidrs[count.index]
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-public-${count.index + 1}"
  })
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-public-rt"
  })
}

resource "aws_route_table_association" "public" {
  count = 2

  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

resource "aws_security_group" "alb" {
  name        = "${local.name_prefix}-alb-sg"
  description = "ALB security group for n8n"
  vpc_id      = aws_vpc.this.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-alb-sg"
  })
}

resource "aws_security_group_rule" "alb_ingress_http" {
  type              = "ingress"
  from_port         = 80
  to_port           = 80
  protocol          = "tcp"
  cidr_blocks       = var.allowed_cidr_blocks
  security_group_id = aws_security_group.alb.id
}

resource "aws_security_group_rule" "alb_egress_all" {
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks       = ["0.0.0.0/0"]
  security_group_id = aws_security_group.alb.id
}

resource "aws_security_group" "task" {
  name        = "${local.name_prefix}-task-sg"
  description = "ECS task security group for n8n"
  vpc_id      = aws_vpc.this.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-task-sg"
  })
}

resource "aws_security_group_rule" "task_ingress_from_alb" {
  type                     = "ingress"
  from_port                = var.container_port
  to_port                  = var.container_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb.id
  security_group_id        = aws_security_group.task.id
}

resource "aws_security_group_rule" "task_egress_all" {
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks       = ["0.0.0.0/0"]
  security_group_id = aws_security_group.task.id
}

resource "aws_security_group" "rds" {
  name        = "${local.name_prefix}-rds-sg"
  description = "RDS security group for n8n"
  vpc_id      = aws_vpc.this.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-rds-sg"
  })
}

resource "aws_security_group_rule" "rds_ingress_from_task" {
  type                     = "ingress"
  from_port                = 5432
  to_port                  = 5432
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.task.id
  security_group_id        = aws_security_group.rds.id
}

resource "aws_security_group" "opensearch" {
  name        = "${local.name_prefix}-opensearch-sg"
  description = "OpenSearch security group for n8n"
  vpc_id      = aws_vpc.this.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-opensearch-sg"
  })
}

resource "aws_security_group_rule" "opensearch_ingress_from_task" {
  type                     = "ingress"
  from_port                = 443
  to_port                  = 443
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.task.id
  security_group_id        = aws_security_group.opensearch.id
}

resource "aws_db_subnet_group" "this" {
  name       = "${local.name_prefix}-db-subnets"
  subnet_ids = aws_subnet.public[*].id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-db-subnets"
  })
}

resource "aws_secretsmanager_secret" "n8n_encryption_key" {
  name                    = "${local.name_prefix}/n8n-encryption-key"
  recovery_window_in_days = 0

  tags = local.common_tags
}

resource "aws_secretsmanager_secret_version" "n8n_encryption_key" {
  secret_id     = aws_secretsmanager_secret.n8n_encryption_key.id
  secret_string = local.n8n_encryption_key_value
}

resource "aws_secretsmanager_secret" "openai_api_key" {
  name                    = "${local.name_prefix}/openai-api-key"
  recovery_window_in_days = 0

  tags = local.common_tags
}

resource "aws_secretsmanager_secret_version" "openai_api_key" {
  secret_id     = aws_secretsmanager_secret.openai_api_key.id
  secret_string = var.openai_api_key
}

resource "aws_secretsmanager_secret" "db_password" {
  name                    = "${local.name_prefix}/db-password"
  recovery_window_in_days = 0

  tags = local.common_tags
}

resource "aws_secretsmanager_secret_version" "db_password" {
  secret_id     = aws_secretsmanager_secret.db_password.id
  secret_string = local.db_password
}

resource "aws_secretsmanager_secret" "opensearch_auth_header" {
  name                    = "${local.name_prefix}/opensearch-auth-header"
  recovery_window_in_days = 0

  tags = local.common_tags
}

resource "aws_secretsmanager_secret_version" "opensearch_auth_header" {
  secret_id     = aws_secretsmanager_secret.opensearch_auth_header.id
  secret_string = local.opensearch_auth_header
}

resource "terraform_data" "opensearch_service_linked_role" {
  provisioner "local-exec" {
    interpreter = ["PowerShell", "-NoProfile", "-Command"]
    command     = <<-EOT
      aws iam get-role --role-name AWSServiceRoleForAmazonOpenSearchService 1>$null 2>$null
      if ($LASTEXITCODE -ne 0) {
        aws iam create-service-linked-role --aws-service-name opensearchservice.amazonaws.com | Out-Null
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
      }
    EOT
  }
}

resource "aws_db_instance" "this" {
  identifier              = "${local.short_prefix}-db"
  engine                  = "postgres"
  instance_class          = var.db_instance_class
  allocated_storage       = var.db_allocated_storage
  db_name                 = var.db_name
  username                = var.db_username
  password                = local.db_password
  port                    = 5432
  db_subnet_group_name    = aws_db_subnet_group.this.name
  vpc_security_group_ids  = [aws_security_group.rds.id]
  publicly_accessible     = false
  storage_encrypted       = true
  backup_retention_period = 0
  skip_final_snapshot     = true
  apply_immediately       = true
  deletion_protection     = false

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-db"
  })
}

resource "aws_opensearch_domain" "this" {
  domain_name    = local.opensearch_domain_name
  engine_version = var.opensearch_engine_version

  depends_on = [terraform_data.opensearch_service_linked_role]

  cluster_config {
    instance_type          = var.opensearch_instance_type
    instance_count         = 1
    zone_awareness_enabled = false
  }

  ebs_options {
    ebs_enabled = true
    volume_size = var.opensearch_volume_size
    volume_type = "gp3"
  }

  advanced_security_options {
    enabled                        = true
    internal_user_database_enabled = true

    master_user_options {
      master_user_name     = var.opensearch_master_username
      master_user_password = local.opensearch_master_password
    }
  }

  encrypt_at_rest {
    enabled = true
  }

  node_to_node_encryption {
    enabled = true
  }

  domain_endpoint_options {
    enforce_https       = true
    tls_security_policy = "Policy-Min-TLS-1-2-2019-07"
  }

  vpc_options {
    subnet_ids         = [aws_subnet.public[0].id]
    security_group_ids = [aws_security_group.opensearch.id]
  }

  access_policies = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowVpcHttpAccess"
        Effect    = "Allow"
        Principal = { AWS = "*" }
        Action    = "es:ESHttp*"
        Resource  = "arn:aws:es:${var.aws_region}:${data.aws_caller_identity.current.account_id}:domain/${local.opensearch_domain_name}/*"
      }
    ]
  })

  tags = merge(local.common_tags, {
    Name = local.opensearch_domain_name
  })
}

resource "aws_cloudwatch_log_group" "this" {
  name              = local.log_group_name
  retention_in_days = var.log_retention_in_days

  tags = local.common_tags
}

resource "aws_iam_role" "execution" {
  name               = "${local.name_prefix}-execution-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_task_assume_role.json

  tags = local.common_tags
}

resource "aws_iam_role_policy_attachment" "execution_managed" {
  role       = aws_iam_role.execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "execution_secrets" {
  name = "${local.name_prefix}-execution-secrets"
  role = aws_iam_role.execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue"
        ]
        Resource = [
          aws_secretsmanager_secret.n8n_encryption_key.arn,
          aws_secretsmanager_secret.openai_api_key.arn,
          aws_secretsmanager_secret.db_password.arn,
          aws_secretsmanager_secret.opensearch_auth_header.arn
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "kms:Decrypt"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role" "task" {
  name               = "${local.name_prefix}-task-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_task_assume_role.json

  tags = local.common_tags
}

resource "aws_ecs_cluster" "this" {
  name = local.cluster_name

  tags = local.common_tags
}

resource "aws_lb" "this" {
  name               = local.alb_name
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = aws_subnet.public[*].id

  tags = local.common_tags
}

resource "aws_lb_target_group" "this" {
  name        = local.target_group_name
  port        = var.container_port
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = aws_vpc.this.id

  health_check {
    enabled             = true
    protocol            = "HTTP"
    path                = "/healthz"
    matcher             = "200"
    interval            = 30
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 5
  }

  tags = local.common_tags
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.this.arn
  }
}

resource "aws_ecs_task_definition" "this" {
  family                   = local.name_prefix
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = tostring(var.ecs_cpu)
  memory                   = tostring(var.ecs_memory)
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn

  container_definitions = jsonencode([
    {
      name      = "n8n"
      image     = var.n8n_image
      essential = true
      portMappings = [
        {
          containerPort = var.container_port
          hostPort      = var.container_port
          protocol      = "tcp"
        }
      ]
      environment = [
        { name = "N8N_PROTOCOL", value = "http" },
        { name = "N8N_HOST", value = aws_lb.this.dns_name },
        { name = "N8N_PORT", value = tostring(var.container_port) },
        { name = "WEBHOOK_URL", value = local.n8n_base_url },
        { name = "N8N_EDITOR_BASE_URL", value = local.n8n_base_url },
        { name = "N8N_SECURE_COOKIE", value = "false" },
        { name = "N8N_PROXY_HOPS", value = "1" },
        { name = "N8N_BLOCK_ENV_ACCESS_IN_NODE", value = "false" },
        { name = "EXECUTIONS_PROCESS", value = "main" },
        { name = "N8N_LOG_LEVEL", value = "info" },
        { name = "N8N_DIAGNOSTICS_ENABLED", value = "false" },
        { name = "N8N_PERSONALIZATION_ENABLED", value = "false" },
        { name = "N8N_VERSION_NOTIFICATIONS_ENABLED", value = "false" },
        { name = "DB_TYPE", value = "postgresdb" },
        { name = "DB_POSTGRESDB_HOST", value = aws_db_instance.this.address },
        { name = "DB_POSTGRESDB_PORT", value = tostring(aws_db_instance.this.port) },
        { name = "DB_POSTGRESDB_DATABASE", value = var.db_name },
        { name = "DB_POSTGRESDB_USER", value = var.db_username },
        { name = "DB_POSTGRESDB_SCHEMA", value = "public" },
        { name = "DB_POSTGRESDB_SSL_ENABLED", value = "true" },
        { name = "DB_POSTGRESDB_SSL_REJECT_UNAUTHORIZED", value = "false" },
        { name = "OPENSEARCH_ENDPOINT", value = local.opensearch_endpoint },
        { name = "OPENSEARCH_INDEX", value = var.opensearch_index_name },
        { name = "OPENAI_LLM_MODEL", value = var.openai_llm_model },
        { name = "OPENAI_EMBEDDING_MODEL", value = var.openai_embedding_model },
        { name = "OPENAI_EMBEDDING_DIMENSIONS", value = tostring(var.openai_embedding_dimensions) },
        { name = "TOOL_WEB_SEARCH_ENABLED", value = tostring(var.tool_web_search_enabled) },
        { name = "TOOL_CALCULATOR_ENABLED", value = tostring(var.tool_calculator_enabled) },
        { name = "TOOL_DATETIME_ENABLED", value = tostring(var.tool_datetime_enabled) }
      ]
      secrets = [
        { name = "N8N_ENCRYPTION_KEY", valueFrom = aws_secretsmanager_secret.n8n_encryption_key.arn },
        { name = "OPENAI_API_KEY", valueFrom = aws_secretsmanager_secret.openai_api_key.arn },
        { name = "OPENSEARCH_AUTH_HEADER", valueFrom = aws_secretsmanager_secret.opensearch_auth_header.arn },
        { name = "DB_POSTGRESDB_PASSWORD", valueFrom = aws_secretsmanager_secret.db_password.arn }
      ]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          awslogs-group         = aws_cloudwatch_log_group.this.name
          awslogs-region        = var.aws_region
          awslogs-stream-prefix = "n8n"
        }
      }
    }
  ])

  tags = local.common_tags
}

resource "aws_ecs_service" "this" {
  name                              = local.service_name
  cluster                           = aws_ecs_cluster.this.id
  task_definition                   = aws_ecs_task_definition.this.arn
  desired_count                     = var.desired_count
  launch_type                       = "FARGATE"
  enable_execute_command            = true
  wait_for_steady_state             = true
  health_check_grace_period_seconds = 180

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.this.arn
    container_name   = "n8n"
    container_port   = var.container_port
  }

  network_configuration {
    assign_public_ip = true
    subnets          = aws_subnet.public[*].id
    security_groups  = [aws_security_group.task.id]
  }

  depends_on = [
    aws_lb_listener.http
  ]

  tags = local.common_tags
}
