# AWS_PAAS Architecture

This document describes the architecture of the `AWS_PAAS` pack.

## Deployment Model

The `AWS_PAAS` pack runs the current n8n-based Agentic AI RAG system on Amazon ECS/Fargate.

## Main Components

- `Application Load Balancer`
  - public entry point for the n8n UI and webhook endpoints
- `Amazon ECS/Fargate`
  - runs the n8n Community Edition container
- `Amazon RDS PostgreSQL`
  - stores n8n users, workflow state, credentials metadata, and execution data
- `Amazon OpenSearch Service`
  - stores document chunks and embedding vectors in the `rag-documents` index
- `AWS Secrets Manager`
  - stores `N8N_ENCRYPTION_KEY`, `OPENAI_API_KEY`, `OPENSEARCH_AUTH_HEADER`, and the database password
- `OpenAI API`
  - provides embeddings, final answer generation, and optional web-search helper behavior

## Public Access Pattern

For the first deployment without a custom domain:

- clients connect to the ALB DNS name over HTTP
- the ALB forwards traffic to the n8n container on port `5678`
- n8n is configured with the ALB DNS name as:
  - `N8N_HOST`
  - `WEBHOOK_URL`
  - `N8N_EDITOR_BASE_URL`

This keeps the first deployment simple and avoids having to buy a domain or issue a certificate before the system is proven working.

## Network Shape

```mermaid
flowchart LR
    User["Browser or API client"] --> ALB["Application Load Balancer :80"]
    ALB --> ECS["ECS/Fargate task running n8n :5678"]
    ECS --> RDS["Amazon RDS PostgreSQL"]
    ECS --> OS["Amazon OpenSearch Service"]
    ECS --> SM["AWS Secrets Manager"]
    ECS --> OAI["OpenAI API"]
```

## Security Group Model

- `n8n-alb-sg`
  - allows inbound `80` from your IP range
- `n8n-task-sg`
  - allows inbound `5678` from `n8n-alb-sg`
- `n8n-rds-sg`
  - allows inbound `5432` from `n8n-task-sg`
- `n8n-opensearch-sg`
  - allows inbound `443` from `n8n-task-sg`

## Why The Pack Uses An ALB DNS Name Instead Of A Raw IP

- ECS/Fargate tasks can receive public IPs, but those IPs belong to task ENIs and can change whenever tasks are replaced.
- Application Load Balancers are meant to be reached by DNS name.
- If you later need stable static public IPs, the frontend should move to a Network Load Balancer with Elastic IPs.

## Runtime Configuration Flow

The ECS task definition injects runtime values into n8n through environment variables and Secrets Manager references.

Important runtime values:

- `N8N_PROTOCOL`
- `N8N_HOST`
- `WEBHOOK_URL`
- `N8N_EDITOR_BASE_URL`
- `N8N_SECURE_COOKIE`
- `N8N_PROXY_HOPS`
- `DB_POSTGRESDB_*`
- `OPENSEARCH_ENDPOINT`
- `OPENSEARCH_INDEX`
- `OPENAI_LLM_MODEL`
- `OPENAI_EMBEDDING_MODEL`
- `OPENAI_EMBEDDING_DIMENSIONS`
- `TOOL_WEB_SEARCH_ENABLED`
- `TOOL_CALCULATOR_ENABLED`
- `TOOL_DATETIME_ENABLED`

## Workflow Set

The AWS pack imports three workflows:

1. `01-document-ingestion.json`
2. `02-rag-query.json`
3. `03-health-check.json`

## Workflow 1: Document Ingestion

Purpose:

- accept documents through `POST /webhook/rag/ingest`
- split text into chunks
- create embeddings with OpenAI
- bulk index the chunks into OpenSearch

High-level flow:

1. validate request
2. normalize document input
3. split documents into chunks
4. call OpenAI embeddings
5. build bulk index request
6. write chunk documents into OpenSearch
7. return ingestion summary

Stored OpenSearch data includes:

- `content`
- `embedding`
- `document_id`
- `collection`
- `chunk_index`
- `metadata`
- `indexed_at`

## Workflow 2: Agentic Query

Purpose:

- accept a question through `POST /webhook/rag/query`
- embed the query
- search OpenSearch for matching chunks
- optionally add helper-tool context
- generate the final answer with OpenAI

High-level flow:

1. validate request
2. create query embedding
3. run vector search in OpenSearch
4. collect retrieved knowledge base chunks
5. inspect the query for helper-tool triggers
6. add supplemental context
7. send the final prompt to OpenAI
8. return answer, sources, and tool usage

## Agentic Behavior In This Pack

This is workflow-orchestrated agentic behavior, not true MCP server integration.

Current helper capabilities:

- `calculate`
- `get_current_datetime`
- `web_search`

The workflow decides when to add those helper results before calling the final OpenAI model.

## Workflow 3: Health Check

Purpose:

- expose `GET /webhook/rag/health`
- verify OpenSearch cluster health
- verify the RAG index exists
- verify OpenAI embeddings are reachable
- report the enabled helper-tool flags

This workflow is the fastest end-to-end health check for the full RAG stack.

## Data Persistence

### n8n state

Stored in Amazon RDS PostgreSQL:

- owner account
- workflow metadata
- activation state
- execution history
- internal n8n tables

### vectors and chunks

Stored in Amazon OpenSearch Service:

- the `rag-documents` index
- one document per chunk
- vector embeddings stored in the `embedding` field

## Operational Sequence

The normal runtime sequence is:

1. client reaches ALB
2. ALB routes request to the n8n ECS task
3. n8n reads its runtime values from environment variables and injected secrets
4. query and ingest workflows call OpenAI and OpenSearch as needed
5. results return through the ALB to the client

## What Changes Later When You Add HTTPS

When you add a custom domain and TLS later:

- the ALB listener changes from HTTP to HTTPS
- `N8N_PROTOCOL` changes to `https`
- `WEBHOOK_URL` changes to the final HTTPS URL
- `N8N_EDITOR_BASE_URL` changes to the final HTTPS URL
- `N8N_SECURE_COOKIE` changes to `true`

The rest of the RAG workflow architecture stays the same.
