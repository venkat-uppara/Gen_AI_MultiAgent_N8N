# AWS_PAAS Testing Guide

This guide assumes the ECS/Fargate deployment is already up and reachable through the ALB DNS name.

## Base URL

Use:

```text
http://YOUR_ALB_DNS_NAME
```

Examples:

- `http://YOUR_ALB_DNS_NAME/healthz`
- `http://YOUR_ALB_DNS_NAME/webhook/rag/health`

## What To Confirm Before Testing

Confirm these first:

- ECS service shows `1/1` running tasks
- target group shows a healthy target
- the ALB DNS name opens the n8n UI
- all three workflows are imported and activated

## Test 1: Native n8n Health Endpoint

Open in a browser:

```text
http://YOUR_ALB_DNS_NAME/healthz
```

Expected result:

- HTTP `200`

## Test 2: RAG Health Workflow

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test health
```

Expected result:

- status `healthy` or `degraded`
- OpenSearch service check returns healthy or at least reachable
- embedding model check returns healthy
- the output reports the configured model names and OpenSearch index
- before the first ingest, the RAG index may show as `missing`, which is expected

## Test 3: Ingest Sample Text

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test ingest
```

Expected result:

- documents are chunked
- embeddings are generated
- the `rag-documents` index is created automatically if it does not exist yet
- records are written into `rag-documents`

## Test 4: Ingest Multiple Documents

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test ingest-multiple
```

Expected result:

- multiple documents ingest successfully
- response includes the indexed document count and chunk count

## Test 5: Query The Knowledge Base

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test query
```

Expected result:

- query returns a natural-language answer
- response includes `sources`
- sources reference the ingested collection

## Test 6: Tool Use

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test agentic
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test datetime
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test web-search
```

Expected result:

- calculator scenario returns a computed value
- datetime scenario reports current time/date context
- web-search scenario shows a `web_search` tool call when relevant

## Test 7: Multi-Turn Conversation

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test multi-turn
```

Expected result:

- follow-up query uses the earlier context
- response contains the same `session_id`

## Test 8: Error Handling

Run:

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test errors
```

Expected result:

- invalid requests return structured JSON errors
- the workflow does not crash or return HTML error pages

## File Ingestion Testing From The Terminal

The test helper also supports ingesting local files and folders.

Supported file types:

- `.json`
- `.md`
- `.pdf`
- `.doc`
- `.docx`
- `.txt`
- other text-like files handled by the script

### Ingest One File

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --ingest-path .\sample.pdf --collection demo
```

### Ingest A Folder

```powershell
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --ingest-path .\sample-docs --collection demo
```

Expected result:

- files are read locally by the tester
- extracted text is sent to the ingest webhook as JSON
- embeddings are stored in OpenSearch

## Where The Embeddings Are Stored

The vector store for this AWS pack is Amazon OpenSearch Service.

- index name: `rag-documents`
- each stored record is a chunk plus its embedding and metadata

The normal AWS_PAAS path does not create the index from your laptop, because the OpenSearch domain is private inside the VPC.

The index is created automatically on the first successful ingest request from n8n.

## Quick Smoke Test Order

If you want the shortest possible validation path, do it in this order:

1. Open `http://YOUR_ALB_DNS_NAME/healthz`
2. Run `--test health`
3. Run `--test ingest`
4. Run `--test query`
5. Run `--test all`

## Troubleshooting Shortlist

### `Cannot connect`

Check:

- ALB security group allows your current public IP
- ALB listener forwards to the correct target group
- target group has a healthy target

### `OPENAI_API_KEY is not configured`

Check:

- the secret exists in Secrets Manager
- the execution role can read that secret
- the secret ARN in `ecs-settings.json` is correct
- the ECS service has been redeployed after the change

### `Vector search failed`

Check:

- OpenSearch domain is active
- `OPENSEARCH_AUTH_HEADER` is correct
- the index exists
- the OpenSearch security group allows `443` from the ECS task security group

### `Response is not valid JSON`

Check:

- you are pointing to the ALB base URL
- the workflow is active
- the ALB is not returning an n8n setup screen or login page instead of the webhook response
