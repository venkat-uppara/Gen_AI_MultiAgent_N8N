#!/usr/bin/env python3
"""Render ECS task and service JSON from the AWS_PAAS settings file.

This is the cross-platform companion to render-ecs-assets.ps1 so Linux-based
AWS CodeBuild jobs can render the ECS assets without PowerShell.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def require_value(name: str, value: Any) -> None:
    if value is None:
        raise ValueError(f"Missing required value in ecs-settings.json: {name}")
    if isinstance(value, str) and not value.strip():
        raise ValueError(f"Missing required value in ecs-settings.json: {name}")


def require_nested(root: dict[str, Any], name: str, *path: str) -> Any:
    value: Any = root
    for key in path:
        if not isinstance(value, dict) or key not in value:
            raise ValueError(f"Missing required value in ecs-settings.json: {name}")
        value = value[key]
    require_value(name, value)
    return value


def load_settings(settings_path: Path) -> dict[str, Any]:
    settings = json.loads(settings_path.read_text(encoding="utf-8"))

    top_level_required = [
        "region",
        "family",
        "taskDefinition",
        "serviceName",
        "containerName",
        "image",
        "cpu",
        "memory",
        "clusterArn",
        "executionRoleArn",
        "taskRoleArn",
        "targetGroupArn",
        "logGroup",
        "n8nProtocol",
        "n8nHost",
        "webhookUrl",
        "editorBaseUrl",
        "opensearchEndpoint",
        "opensearchIndex",
        "openAiLlmModel",
        "openAiEmbeddingModel",
        "openAiEmbeddingDimensions",
    ]

    for key in top_level_required:
        require_value(key, settings.get(key))

    require_nested(settings, "database.host", "database", "host")
    require_nested(settings, "database.port", "database", "port")
    require_nested(settings, "database.name", "database", "name")
    require_nested(settings, "database.user", "database", "user")
    require_nested(settings, "database.schema", "database", "schema")

    require_nested(settings, "secrets.n8nEncryptionKeyArn", "secrets", "n8nEncryptionKeyArn")
    require_nested(settings, "secrets.openAiApiKeyArn", "secrets", "openAiApiKeyArn")
    require_nested(settings, "secrets.openSearchAuthHeaderArn", "secrets", "openSearchAuthHeaderArn")
    require_nested(settings, "secrets.dbPasswordArn", "secrets", "dbPasswordArn")

    subnet_ids = settings.get("subnetIds") or []
    security_group_ids = settings.get("securityGroupIds") or []
    if len(subnet_ids) < 1:
        raise ValueError("ecs-settings.json must contain at least one subnet ID.")
    if len(security_group_ids) < 1:
        raise ValueError("ecs-settings.json must contain at least one security group ID.")

    return settings


def escape_json_string(value: Any) -> str:
    if value is None:
        return ""
    text = json.dumps(str(value), ensure_ascii=False)
    return text[1:-1]


def to_json_array(values: list[Any]) -> str:
    return json.dumps(list(values), ensure_ascii=False, separators=(",", ":"))


def render(settings: dict[str, Any], task_template: str, service_template: str) -> tuple[str, str]:
    n8n_secure_cookie = str(
        settings.get("n8nSecureCookie")
        if str(settings.get("n8nSecureCookie", "")).strip()
        else ("true" if str(settings["n8nProtocol"]) == "https" else "false")
    )

    replacements = {
        "__FAMILY__": escape_json_string(settings["family"]),
        "__TASK_DEFINITION__": escape_json_string(settings["taskDefinition"]),
        "__SERVICE_NAME__": escape_json_string(settings["serviceName"]),
        "__CONTAINER_NAME__": escape_json_string(settings["containerName"]),
        "__IMAGE__": escape_json_string(settings["image"]),
        "__CPU__": escape_json_string(settings["cpu"]),
        "__MEMORY__": escape_json_string(settings["memory"]),
        "__CONTAINER_PORT__": str(settings.get("containerPort", 5678)),
        "__DESIRED_COUNT__": str(settings.get("desiredCount", 1)),
        "__ASSIGN_PUBLIC_IP__": escape_json_string(settings.get("assignPublicIp", "ENABLED")),
        "__CLUSTER_ARN__": escape_json_string(settings["clusterArn"]),
        "__EXECUTION_ROLE_ARN__": escape_json_string(settings["executionRoleArn"]),
        "__TASK_ROLE_ARN__": escape_json_string(settings["taskRoleArn"]),
        "__TARGET_GROUP_ARN__": escape_json_string(settings["targetGroupArn"]),
        "__LOG_GROUP__": escape_json_string(settings["logGroup"]),
        "__REGION__": escape_json_string(settings["region"]),
        "__N8N_PROTOCOL__": escape_json_string(settings["n8nProtocol"]),
        "__N8N_HOST__": escape_json_string(settings["n8nHost"]),
        "__WEBHOOK_URL__": escape_json_string(settings["webhookUrl"]),
        "__EDITOR_BASE_URL__": escape_json_string(settings["editorBaseUrl"]),
        "__N8N_SECURE_COOKIE__": escape_json_string(n8n_secure_cookie),
        "__DB_HOST__": escape_json_string(settings["database"]["host"]),
        "__DB_PORT__": escape_json_string(settings["database"]["port"]),
        "__DB_NAME__": escape_json_string(settings["database"]["name"]),
        "__DB_USER__": escape_json_string(settings["database"]["user"]),
        "__DB_SCHEMA__": escape_json_string(settings["database"]["schema"]),
        "__OPENSEARCH_ENDPOINT__": escape_json_string(settings["opensearchEndpoint"]),
        "__OPENSEARCH_INDEX__": escape_json_string(settings["opensearchIndex"]),
        "__OPENAI_LLM_MODEL__": escape_json_string(settings["openAiLlmModel"]),
        "__OPENAI_EMBEDDING_MODEL__": escape_json_string(settings["openAiEmbeddingModel"]),
        "__OPENAI_EMBEDDING_DIMENSIONS__": escape_json_string(settings["openAiEmbeddingDimensions"]),
        "__TOOL_WEB_SEARCH_ENABLED__": escape_json_string(settings.get("toolWebSearchEnabled", "true")),
        "__TOOL_CALCULATOR_ENABLED__": escape_json_string(settings.get("toolCalculatorEnabled", "true")),
        "__TOOL_DATETIME_ENABLED__": escape_json_string(settings.get("toolDatetimeEnabled", "true")),
        "__N8N_ENCRYPTION_KEY_SECRET_ARN__": escape_json_string(settings["secrets"]["n8nEncryptionKeyArn"]),
        "__OPENAI_API_KEY_SECRET_ARN__": escape_json_string(settings["secrets"]["openAiApiKeyArn"]),
        "__OPENSEARCH_AUTH_HEADER_SECRET_ARN__": escape_json_string(settings["secrets"]["openSearchAuthHeaderArn"]),
        "__DB_PASSWORD_SECRET_ARN__": escape_json_string(settings["secrets"]["dbPasswordArn"]),
        "__SUBNET_IDS_JSON__": to_json_array(settings["subnetIds"]),
        "__SECURITY_GROUP_IDS_JSON__": to_json_array(settings["securityGroupIds"]),
    }

    for key, value in replacements.items():
        task_template = task_template.replace(key, value)
        service_template = service_template.replace(key, value)

    return task_template.rstrip("\r\n") + "\n", service_template.rstrip("\r\n") + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Render ECS task and service JSON from ecs-settings.json")
    parser.add_argument(
        "--settings-path",
        default=str(Path(__file__).resolve().parent.parent / "templates" / "ecs-settings.json"),
        help="Path to ecs-settings.json",
    )
    parser.add_argument(
        "--task-out",
        default=None,
        help="Path to write ecs-task-definition.generated.json",
    )
    parser.add_argument(
        "--service-out",
        default=None,
        help="Path to write ecs-service.generated.json",
    )
    args = parser.parse_args()

    settings_path = Path(args.settings_path).resolve()
    package_dir = settings_path.parent.parent
    task_out = Path(args.task_out).resolve() if args.task_out else package_dir / "ecs-task-definition.generated.json"
    service_out = Path(args.service_out).resolve() if args.service_out else package_dir / "ecs-service.generated.json"

    settings = load_settings(settings_path)
    task_template_path = settings_path.parent / "ecs-task-definition.template.json"
    service_template_path = settings_path.parent / "ecs-service.template.json"

    task_template = task_template_path.read_text(encoding="utf-8")
    service_template = service_template_path.read_text(encoding="utf-8")
    rendered_task, rendered_service = render(settings, task_template, service_template)

    task_out.write_text(rendered_task, encoding="utf-8")
    service_out.write_text(rendered_service, encoding="utf-8")

    print("Generated ECS assets:")
    print(f"  {task_out}")
    print(f"  {service_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
