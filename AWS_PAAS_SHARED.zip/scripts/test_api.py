#!/usr/bin/env python3
r"""
Test the n8n RAG API Endpoints

Usage:
    pip install requests
    python test_api.py
    python test_api.py --base-url http://your-alb-name-1234567890.us-east-1.elb.amazonaws.com
    python test_api.py --base-url http://your-alb-name-1234567890.us-east-1.elb.amazonaws.com --username admin --password secret
    python test_api.py --test health
    python test_api.py --test ingest
    python test_api.py --test ingest-multiple
    python test_api.py --test query
    python test_api.py --test agentic
    python test_api.py --test datetime
    python test_api.py --test multi-turn
    python test_api.py --test web-search
    python test_api.py --test errors
    python test_api.py --test all        # default
    python test_api.py --query "What is my name?" --collection my-kb
    python test_api.py --ingest-path .\sample.pdf --collection my-kb
    python test_api.py --ingest-path .\docs .\notes.md --collection my-kb

Available tests: health, ingest, ingest-multiple, query, agentic, datetime, multi-turn, web-search, errors, all
"""

import argparse
import json
from pathlib import Path
import re
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
import zlib

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    import requests
except ImportError:
    print("ERROR: 'requests' library not found.")
    print("Install it with:  pip install requests")
    sys.exit(1)


# ── ANSI colours ─────────────────────────────────────────────────────────────
GREEN  = "\033[0;32m"
RED    = "\033[0;31m"
YELLOW = "\033[1;33m"
BLUE   = "\033[0;34m"
CYAN   = "\033[0;36m"
RESET  = "\033[0m"

TEST_COLLECTION = "acme-policy"
MULTI_DOC_COLLECTION = "acme-ops"
DEFAULT_FILE_COLLECTION = "uploaded-files"
TEXT_FILE_EXTENSIONS = {
    ".txt", ".text", ".md", ".markdown", ".json", ".jsonl", ".log",
    ".csv", ".xml", ".yml", ".yaml", ".html", ".htm", ".rst",
}
SUPPORTED_FILE_EXTENSIONS = TEXT_FILE_EXTENSIONS | {".pdf", ".doc", ".docx"}
DOCX_NAMESPACE = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


def ok(msg: str)   -> None: print(f"{GREEN}✓ {msg}{RESET}")
def fail(msg: str) -> None: print(f"{RED}✗ {msg}{RESET}")
def info(msg: str) -> None: print(f"{YELLOW}ℹ {msg}{RESET}")
def hdr(msg: str)  -> None:
    sep = "=" * 55
    print(f"\n{BLUE}{sep}{RESET}")
    print(f"{BLUE} {msg}{RESET}")
    print(f"{BLUE}{sep}{RESET}")


# ── Helper ────────────────────────────────────────────────────────────────────
class FileExtractionError(RuntimeError):
    pass


def post(session: requests.Session, url: str, payload: dict, timeout: int = 120) -> tuple[int, dict]:
    try:
        resp = session.post(url, json=payload, timeout=timeout)
        if not resp.content:
            fail(f"Empty response body  (HTTP {resp.status_code})")
            return resp.status_code, {}
        try:
            return resp.status_code, resp.json()
        except ValueError:
            fail(f"Response is not valid JSON  (HTTP {resp.status_code})")
            info(f"Raw response: {resp.text[:500]}")
            return resp.status_code, {}
    except requests.exceptions.ConnectionError:
        fail(f"Cannot connect to {url}")
        info("Is n8n running? Check the base URL.")
        return 0, {}
    except requests.exceptions.Timeout:
        fail(f"Request timed out ({timeout} s)")
        return 0, {}


def get(session: requests.Session, url: str, timeout: int = 60) -> tuple[int, dict]:
    try:
        resp = session.get(url, timeout=timeout)
        if not resp.content:
            fail(f"Empty response body  (HTTP {resp.status_code})")
            return resp.status_code, {}
        try:
            return resp.status_code, resp.json()
        except ValueError:
            fail(f"Response is not valid JSON  (HTTP {resp.status_code})")
            info(f"Raw response: {resp.text[:500]}")
            return resp.status_code, {}
    except requests.exceptions.ConnectionError:
        fail(f"Cannot connect to {url}")
        return 0, {}
    except requests.exceptions.Timeout:
        fail(f"Request timed out ({timeout} s)")
        return 0, {}


def pretty(data: dict) -> None:
    print(json.dumps(data, indent=2))


def contains_any(text: str, patterns: list[str]) -> bool:
    lowered = text.lower()
    return any(pattern.lower() in lowered for pattern in patterns)


def normalise_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def title_from_path(path: Path) -> str:
    return path.stem.replace("_", " ").replace("-", " ").strip() or path.name


def read_text_file(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="replace")
    if path.suffix.lower() in {".json", ".jsonl"}:
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return normalise_text(raw)
        return normalise_text(json.dumps(parsed, indent=2, ensure_ascii=False))
    return normalise_text(raw)


def read_docx_file(path: Path) -> str:
    paragraph_text: list[str] = []
    try:
        with zipfile.ZipFile(path) as archive:
            xml_names = sorted(
                name
                for name in archive.namelist()
                if name.startswith("word/")
                and name.endswith(".xml")
                and (
                    name.endswith("document.xml")
                    or "/header" in name
                    or "/footer" in name
                    or name.endswith("footnotes.xml")
                    or name.endswith("endnotes.xml")
                )
            )
            for xml_name in xml_names:
                root = ET.fromstring(archive.read(xml_name))
                for para in root.findall(".//w:p", DOCX_NAMESPACE):
                    parts = [node.text or "" for node in para.findall(".//w:t", DOCX_NAMESPACE)]
                    paragraph = "".join(parts).strip()
                    if paragraph:
                        paragraph_text.append(paragraph)
    except zipfile.BadZipFile as exc:
        raise FileExtractionError(f"{path.name}: invalid DOCX file") from exc
    except ET.ParseError as exc:
        raise FileExtractionError(f"{path.name}: could not parse DOCX XML") from exc

    text = normalise_text("\n\n".join(paragraph_text))
    if not text:
        raise FileExtractionError(f"{path.name}: DOCX file contained no extractable text")
    return text


def read_pdf_with_python(path: Path) -> str:
    for module_name in ("pypdf", "PyPDF2"):
        try:
            module = __import__(module_name)
        except ImportError:
            continue

        reader = module.PdfReader(str(path))
        pages = []
        for page in reader.pages:
            page_text = page.extract_text() or ""
            if page_text.strip():
                pages.append(page_text.strip())
        text = normalise_text("\n\n".join(pages))
        if text:
            return text

    raise FileExtractionError(
        f"{path.name}: PDF extraction needs pypdf/PyPDF2 or a built-in text-based PDF fallback"
    )


def decode_pdf_literal_string(value: str) -> str:
    output: list[str] = []
    idx = 0
    while idx < len(value):
        char = value[idx]
        if char != "\\":
            output.append(char)
            idx += 1
            continue

        idx += 1
        if idx >= len(value):
            break

        escaped = value[idx]
        simple_map = {
            "n": "\n",
            "r": "\r",
            "t": "\t",
            "b": "\b",
            "f": "\f",
            "(": "(",
            ")": ")",
            "\\": "\\",
        }
        if escaped in simple_map:
            output.append(simple_map[escaped])
            idx += 1
            continue

        if escaped in "\r\n":
            idx += 1
            if escaped == "\r" and idx < len(value) and value[idx] == "\n":
                idx += 1
            continue

        if escaped in "01234567":
            octal_digits = escaped
            idx += 1
            for _ in range(2):
                if idx < len(value) and value[idx] in "01234567":
                    octal_digits += value[idx]
                    idx += 1
                else:
                    break
            output.append(chr(int(octal_digits, 8)))
            continue

        output.append(escaped)
        idx += 1

    return "".join(output)


def extract_pdf_strings_from_text_block(block: str) -> list[str]:
    strings: list[str] = []
    idx = 0
    while idx < len(block):
        if block[idx] != "(":
            idx += 1
            continue

        idx += 1
        depth = 1
        current: list[str] = []
        while idx < len(block) and depth > 0:
            char = block[idx]
            if char == "\\":
                if idx + 1 < len(block):
                    current.append(char)
                    idx += 1
                    current.append(block[idx])
                idx += 1
                continue
            if char == "(":
                depth += 1
                current.append(char)
                idx += 1
                continue
            if char == ")":
                depth -= 1
                if depth == 0:
                    idx += 1
                    break
                current.append(char)
                idx += 1
                continue

            current.append(char)
            idx += 1

        decoded = decode_pdf_literal_string("".join(current))
        if decoded and not decoded.isspace():
            strings.append(decoded)

    return strings


def read_pdf_with_builtin_parser(path: Path) -> str:
    data = path.read_bytes()
    stream_text_blocks: list[str] = []

    for match in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
        raw_stream = match.group(1)
        try:
            stream = zlib.decompress(raw_stream)
        except Exception:
            continue

        try:
            decoded_stream = stream.decode("latin-1")
        except UnicodeDecodeError:
            continue

        for text_block in re.findall(r"BT(.*?)ET", decoded_stream, re.S):
            pieces = extract_pdf_strings_from_text_block(text_block)
            if pieces:
                stream_text_blocks.append("".join(pieces))

    text = normalise_text("\n\n".join(stream_text_blocks))
    if not text:
        raise FileExtractionError(
            f"{path.name}: PDF text could not be extracted. "
            "Use a text-based PDF or install pypdf/PyPDF2 for broader support."
        )
    return text


def read_with_word(path: Path) -> str:
    try:
        import pythoncom
        from win32com import client
    except ImportError as exc:
        raise FileExtractionError(
            f"{path.name}: extracting .doc/.pdf on this machine needs Microsoft Word "
            "and pywin32 (win32com)"
        ) from exc

    pythoncom.CoInitialize()
    word = None
    document = None
    try:
        word = client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0
        document = word.Documents.Open(
            str(path.resolve()),
            ConfirmConversions=False,
            ReadOnly=True,
            AddToRecentFiles=False,
            Visible=False,
            OpenAndRepair=True,
        )
        text = normalise_text(document.Content.Text)
        if not text:
            raise FileExtractionError(f"{path.name}: Microsoft Word returned no text")
        return text
    except FileExtractionError:
        raise
    except Exception as exc:
        raise FileExtractionError(
            f"{path.name}: Microsoft Word could not extract text from this file ({exc})"
        ) from exc
    finally:
        if document is not None:
            document.Close(False)
        if word is not None:
            word.Quit()
        pythoncom.CoUninitialize()


def extract_text_from_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in TEXT_FILE_EXTENSIONS:
        return read_text_file(path)
    if suffix == ".docx":
        return read_docx_file(path)
    if suffix == ".pdf":
        try:
            return read_pdf_with_python(path)
        except FileExtractionError:
            return read_pdf_with_builtin_parser(path)
    if suffix == ".doc":
        return read_with_word(path)
    raise FileExtractionError(
        f"{path.name}: unsupported file type '{suffix or '<none>'}'"
    )


def resolve_ingest_files(inputs: list[str]) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()

    for raw in inputs:
        path = Path(raw).expanduser()
        if not path.exists():
            raise FileExtractionError(f"Path not found: {path}")

        candidates: list[Path]
        if path.is_dir():
            candidates = sorted(
                candidate for candidate in path.rglob("*")
                if candidate.is_file() and candidate.suffix.lower() in SUPPORTED_FILE_EXTENSIONS
            )
            if not candidates:
                raise FileExtractionError(
                    f"No supported files found under directory: {path}"
                )
        else:
            if path.suffix.lower() not in SUPPORTED_FILE_EXTENSIONS:
                raise FileExtractionError(
                    f"Unsupported file type for {path.name}. Supported: "
                    + ", ".join(sorted(SUPPORTED_FILE_EXTENSIONS))
                )
            candidates = [path]

        for candidate in candidates:
            resolved = str(candidate.resolve())
            if resolved not in seen:
                seen.add(resolved)
                files.append(candidate.resolve())

    return files


def build_documents_from_files(paths: list[Path]) -> list[dict]:
    documents = []
    for path in paths:
        info(f"Extracting {path.name}")
        content = extract_text_from_file(path)
        documents.append(
            {
                "content": content,
                "metadata": {
                    "source": path.name,
                    "title": title_from_path(path),
                    "path": str(path),
                    "file_type": path.suffix.lower().lstrip("."),
                },
            }
        )
        info(f"  Extracted {len(content):,} characters")
    return documents


def chunked(values: list, size: int) -> list[list]:
    return [values[idx:idx + size] for idx in range(0, len(values), size)]


def ingest_custom_files(
    session: requests.Session,
    base_url: str,
    input_paths: list[str],
    collection: str,
) -> bool:
    hdr("TEST: Custom File Ingestion")
    try:
        files = resolve_ingest_files(input_paths)
        documents = build_documents_from_files(files)
    except FileExtractionError as exc:
        fail(str(exc))
        return False

    info(f"Resolved {len(files)} supported file(s)")
    print()

    total_docs = 0
    total_chunks = 0
    total_tokens = 0
    all_document_ids: list[str] = []
    batches = chunked(documents, 50)

    for batch_index, batch in enumerate(batches, start=1):
        payload = {
            "collection": collection,
            "documents": batch,
        }
        info(
            f"Posting batch {batch_index}/{len(batches)} "
            f"with {len(batch)} document(s)"
        )
        status, body = post(session, f"{base_url}/webhook/rag/ingest", payload, timeout=240)
        print(f"HTTP Status: {status}")
        pretty(body)
        print()

        if status != 200 or not body.get("success"):
            fail(f"Custom file ingestion FAILED in batch {batch_index}")
            return False

        total_docs += int(body.get("documents_ingested", 0))
        total_chunks += int(body.get("chunks_indexed", 0))
        total_tokens += int(body.get("total_tokens_used", 0))
        all_document_ids.extend(body.get("document_ids", []))
        time.sleep(2)

    ok(
        f"Custom file ingestion PASSED  ({total_docs} docs, "
        f"{total_chunks} chunks, collection='{collection}')"
    )
    info(f"Document IDs created: {len(all_document_ids)}")
    info("You can now query this collection using POST /webhook/rag/query.")
    return True


# ─────────────────────────────────────────────────────────────────────────────
# TEST FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def test_health(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Health Check  →  GET /webhook/rag/health")
    url = f"{base_url}/webhook/rag/health"
    info(f"GET {url}")
    print()

    status, body = get(session, url)
    print(f"HTTP Status: {status}")
    print("Response:")
    pretty(body)

    services = body.get("services") or {}
    svc_status = body.get("status", "unknown")
    rag_index_status = services.get("rag_index", {}).get("status")
    opensearch_status = services.get("opensearch", {}).get("status")
    embeddings_status = services.get("openai_embeddings", {}).get("status")

    if status == 200 and svc_status in ("healthy", "degraded"):
        colour = GREEN if svc_status == "healthy" else YELLOW
        print(f"{colour}✓ Health check PASSED  (status: {svc_status}){RESET}")
        return True

    if (
        status == 207
        and svc_status == "degraded"
        and rag_index_status == "missing"
        and opensearch_status == "healthy"
        and embeddings_status == "healthy"
    ):
        print(f"{YELLOW}✓ Health check PASSED  (status: degraded, index will be created on first ingest){RESET}")
        return True

    fail(f"Health check FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-01 workflow execution log in n8n.")
    else:
        info("Ensure n8n is running and the health-check workflow is active.")
    return False


def test_ingest(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Document Ingestion  →  POST /webhook/rag/ingest")
    url = f"{base_url}/webhook/rag/ingest"
    info(f"POST {url}")
    print()

    payload = {
        "collection": TEST_COLLECTION,
        "documents": [
            {
                "content": (
                    "Acme Electronics return policy: regular unopened items may be returned "
                    "within 30 days of purchase for a full refund. Opened electronics may be "
                    "returned within 14 days of purchase. Opened electronics are subject to "
                    "a 5% restocking fee. To qualify, customers must provide the original "
                    "receipt or order number."
                ),
                "metadata": {
                    "source": "acme-returns.md",
                    "title": "Acme Returns Policy",
                    "author": "Test Suite",
                },
            },
            {
                "content": (
                    "Acme refund policy: approved returns are refunded to the original payment "
                    "method within 5 business days. Returns made with a gift receipt are issued "
                    "as store credit only. Shipping fees are non-refundable unless the item "
                    "arrived damaged or defective."
                ),
                "metadata": {
                    "source": "acme-refunds.md",
                    "title": "Acme Refund Methods",
                },
            },
            {
                "content": (
                    "Acme support notes: laptops, tablets, and smart home devices are classified "
                    "as electronics. Accessories like sleeves, cables, and adapters are classified "
                    "as regular items unless explicitly marked otherwise."
                ),
                "metadata": {
                    "source": "acme-support.md",
                    "title": "Acme Product Categories",
                },
            },
        ],
    }

    print("Request payload:")
    pretty(payload)
    print()

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    print("Response:")
    pretty(body)

    if status == 200 and body.get("success"):
        chunks = body.get("chunks_indexed", 0)
        ok(f"Ingestion PASSED  ({chunks} chunk(s) indexed)")
        info("Waiting 3 s for OpenSearch to finish indexing…")
        time.sleep(3)
        return True

    fail(f"Ingestion FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-02 workflow execution log in n8n.")
    return False


def test_ingest_multiple(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Ingest Multiple Documents")
    url = f"{base_url}/webhook/rag/ingest"

    payload = {
        "collection": MULTI_DOC_COLLECTION,
        "documents": [
            {
                "content": (
                    "Acme shipping guide: standard shipping arrives in 3 to 5 business days. "
                    "Express shipping arrives in 1 to 2 business days. Orders above $100 "
                    "qualify for free standard shipping."
                ),
                "metadata": {"title": "Acme Shipping Guide", "source": "acme-shipping.md"},
            },
            {
                "content": (
                    "Acme loyalty guide: silver members earn 1 point per dollar, gold members "
                    "earn 2 points per dollar, and platinum members earn 3 points per dollar. "
                    "Points expire after 12 months of inactivity."
                ),
                "metadata": {"title": "Acme Loyalty Guide", "source": "acme-loyalty.md"},
            },
        ],
    }

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    pretty(body)

    if status == 200 and body.get("success"):
        ok(f"Multiple ingestion PASSED  ({body.get('documents_ingested', 0)} docs, "
           f"{body.get('chunks_indexed', 0)} chunks)")
        time.sleep(3)
        return True

    fail(f"Multiple ingestion FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-02 workflow execution log in n8n.")
    return False


def test_query_basic(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Basic RAG Query  →  POST /webhook/rag/query")
    url = f"{base_url}/webhook/rag/query"
    info(f"POST {url}")
    print()

    payload = {
        "query": "What is the return window for opened electronics?",
        "collection": TEST_COLLECTION,
        "top_k": 3,
    }

    print("Request payload:")
    pretty(payload)
    print()

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    print("Response:")
    pretty(body)

    answer = body.get("answer") or ""
    if status == 200 and body.get("success") and contains_any(answer, ["14 day", "14-day", "14 days"]):
        preview = (body.get("answer") or "")[:120]
        ok("Basic RAG query PASSED")
        info(f"Answer preview: {preview}…")
        return True

    fail(f"Basic RAG query FAILED  (HTTP {status})")
    if body.get("success"):
        info("Answer did not clearly mention the 14-day electronics window.")
    if not body:
        info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
    return False


def test_query_agentic(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Agentic Query — Calculator Tool")
    url = f"{base_url}/webhook/rag/query"

    payload = {
        "query": (
            "If I return an opened electronics purchase worth $450.99, "
            "what refund will I get after the 5% restocking fee?"
        ),
        "collection": TEST_COLLECTION,
        "top_k": 5,
        "session_id": "test-session-001",
    }

    print("Request payload:")
    pretty(payload)
    print()

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    print("Response:")
    pretty(body)

    answer = body.get("answer") or ""
    if status == 200 and body.get("success"):
        tool_calls = body.get("tool_calls_made", [])
        calculator_used = any(tc.get("tool") == "calculate" for tc in tool_calls)
        refund_mentioned = contains_any(answer, ["428.44", "$428.44"])
        if not calculator_used and not refund_mentioned:
            fail("Agentic query did not use the calculator tool or mention the computed refund")
            return False
        ok(f"Agentic query PASSED  ({len(tool_calls)} tool call(s) made)")
        for tc in tool_calls:
            info(f"  Tool used: {tc.get('tool')}  →  {str(tc.get('result', ''))[:80]}")
        return True

    fail(f"Agentic query FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
    return False


def test_query_datetime(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Agentic Query — Datetime Tool")
    url = f"{base_url}/webhook/rag/query"

    payload = {
        "query": "I bought an opened laptop today. Based on the policy, what is the last day I can return it?",
        "collection": TEST_COLLECTION,
        "top_k": 3,
    }

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    pretty(body)

    if status == 200 and body.get("success"):
        tool_calls = body.get("tool_calls_made", [])
        datetime_used = any(tc.get("tool") == "get_current_datetime" for tc in tool_calls)
        answer = body.get("answer") or ""
        if datetime_used or contains_any(answer, ["14 day", "14-day", "two weeks"]):
            ok("Datetime query PASSED")
            if datetime_used:
                info("  ✓ get_current_datetime tool was used")
            else:
                info("  ℹ get_current_datetime was not triggered, but the answer still referenced the 14-day window")
            return True
        fail("Datetime query returned success but did not show evidence of using the policy window")
        return False

    fail(f"Datetime query FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
    return False


def test_query_multi_turn(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Multi-Turn Conversation")
    url = f"{base_url}/webhook/rag/query"
    session_id = f"py-test-session-{int(time.time())}"

    # Turn 1
    info("Turn 1: Asking about return window")
    payload1 = {
        "query": "What is the return window for regular items?",
        "collection": TEST_COLLECTION,
        "session_id": session_id,
    }
    status1, body1 = post(session, url, payload1)
    print(f"HTTP Status: {status1}")
    pretty(body1)

    if status1 != 200 or not body1.get("success"):
        fail("Multi-turn Turn 1 FAILED")
        if not body1:
            info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
        return False

    answer1 = body1.get("answer", "")
    if not contains_any(answer1, ["30 day", "30-day", "30 days"]):
        fail("Multi-turn Turn 1 answer did not mention the 30-day regular-item window")
        return False
    ok(f"Turn 1 PASSED  ({len(answer1)} chars in answer)")

    # Turn 2 — sends conversation history
    info("Turn 2: Follow-up question with conversation history")
    payload2 = {
        "query": "Can I get cash back or only store credit?",
        "collection": TEST_COLLECTION,
        "session_id": session_id,
        "conversation_history": [
            {"role": "user",      "content": payload1["query"]},
            {"role": "assistant", "content": answer1},
        ],
    }
    status2, body2 = post(session, url, payload2)
    print(f"HTTP Status: {status2}")
    pretty(body2)

    answer2 = body2.get("answer", "")
    if status2 == 200 and body2.get("success") and contains_any(
        answer2,
        ["original payment", "store credit", "gift receipt"]
    ):
        ok("Multi-turn conversation PASSED")
        return True

    fail(f"Multi-turn Turn 2 FAILED  (HTTP {status2})")
    if body2.get("success"):
        info("Follow-up answer did not mention refund method or store credit guidance.")
    if not body2:
        info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
    return False


def test_web_search(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Agentic Query — Web Search Tool  (uses OpenAI Responses API)")
    url = f"{base_url}/webhook/rag/query"
    info("This test triggers web_search via OpenAI Responses API (web_search_preview).")
    print()

    payload = {
        "query": "What are the latest OpenAI API pricing updates in 2026?",
        "collection": MULTI_DOC_COLLECTION,
        "top_k": 3,
    }

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    pretty(body)

    if status == 200 and body.get("success"):
        tool_calls = body.get("tool_calls_made", [])
        web_used = any(tc.get("tool") == "web_search" for tc in tool_calls)
        ok("Web-search query PASSED")
        if web_used:
            info("  ✓ web_search tool was used")
        else:
            info("  ℹ web_search not triggered — query may not have required a web lookup")
        return True

    fail(f"Web-search query FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
    return False


def test_errors(session: requests.Session, base_url: str) -> bool:
    hdr("TEST: Error Cases")
    passed = 0
    total = 3

    # ── Error 1: empty query ──────────────────────────────────────────────────
    info("Error 1: Empty query string")
    status, body = post(session, f"{base_url}/webhook/rag/query", {"query": ""})
    print(f"HTTP Status: {status}  |  success={body.get('success')}  |  "
          f"error={str(body.get('error', ''))[:80]}")
    if not body.get("success"):
        ok("Empty query correctly rejected")
        passed += 1
    else:
        fail("Empty query should have been rejected")

    # ── Error 2: missing documents ────────────────────────────────────────────
    info("Error 2: Missing 'documents' field in ingest")
    status, body = post(session, f"{base_url}/webhook/rag/ingest", {"collection": "test"})
    print(f"HTTP Status: {status}  |  success={body.get('success')}  |  "
          f"error={str(body.get('error', ''))[:80]}")
    if not body.get("success"):
        ok("Missing 'documents' correctly rejected")
        passed += 1
    else:
        fail("Missing 'documents' should have been rejected")

    # ── Error 3: too many documents (>50) ─────────────────────────────────────
    info("Error 3: Too many documents (51)")
    big_payload = {
        "collection": "test",
        "documents": [{"content": f"Document {i}"} for i in range(51)],
    }
    status, body = post(session, f"{base_url}/webhook/rag/ingest", big_payload)
    print(f"HTTP Status: {status}  |  success={body.get('success')}  |  "
          f"error={str(body.get('error', ''))[:80]}")
    if not body.get("success"):
        ok("Over-limit documents correctly rejected")
        passed += 1
    else:
        fail("Over-limit documents should have been rejected")

    print()
    if passed == total:
        ok(f"All {total} error cases handled correctly")
        return True

    fail(f"{passed}/{total} error cases passed")
    return False


def run_custom_query(
    session: requests.Session,
    base_url: str,
    query_text: str,
    collection: str,
    top_k: int,
) -> bool:
    hdr("TEST: Custom Query  →  POST /webhook/rag/query")
    url = f"{base_url}/webhook/rag/query"
    info(f"POST {url}")
    print()

    payload = {
        "query": query_text,
        "collection": collection,
        "top_k": top_k,
    }

    print("Request payload:")
    pretty(payload)
    print()

    status, body = post(session, url, payload)
    print(f"HTTP Status: {status}")
    print("Response:")
    pretty(body)

    if status == 200 and body.get("success"):
        answer = (body.get("answer") or "").strip()
        if answer:
            ok("Custom query PASSED")
            info(f"Answer: {answer}")
            return True

    fail(f"Custom query FAILED  (HTTP {status})")
    if not body:
        info("Workflow returned an empty response — check the RAG-03 workflow execution log in n8n.")
    return False


# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────────────────────

def print_summary(results: dict[str, bool]) -> None:
    hdr("Test Summary")
    print()
    passed = sum(1 for v in results.values() if v)
    total  = len(results)

    for name, result in results.items():
        if result:
            ok(name)
        else:
            fail(name)

    print()
    colour = GREEN if passed == total else (YELLOW if passed > 0 else RED)
    print(f"{colour}{passed}/{total} test(s) passed{RESET}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

TESTS = {
    "health":          test_health,
    "ingest":          test_ingest,
    "ingest-multiple": test_ingest_multiple,
    "query":           test_query_basic,
    "agentic":         test_query_agentic,
    "datetime":        test_query_datetime,
    "multi-turn":      test_query_multi_turn,
    "web-search":      test_web_search,
    "errors":          test_errors,
}

ALL_TEST_ORDER = [
    "health",
    "ingest",
    "ingest-multiple",
    "query",
    "agentic",
    "datetime",
    "multi-turn",
    "web-search",
    "errors",
]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Test the n8n Agentic AI RAG API endpoints"
    )
    parser.add_argument(
        "--base-url",
        default="http://localhost:5678",
        help="n8n base URL (default: http://localhost:5678)",
    )
    parser.add_argument(
        "--username",
        default="",
        help="n8n basic-auth username (optional)",
    )
    parser.add_argument(
        "--password",
        default="",
        help="n8n basic-auth password (optional)",
    )
    parser.add_argument(
        "--test",
        default="all",
        choices=[*TESTS.keys(), "all"],
        help="Which test to run (default: all)",
    )
    parser.add_argument(
        "--ingest-path",
        nargs="+",
        help=(
            "File(s) or folder(s) to ingest through the existing JSON ingest API. "
            "Supported: .json, .md, .pdf, .doc, .docx, and text-like files."
        ),
    )
    parser.add_argument(
        "--query",
        dest="query_text",
        help="Send a custom query to /webhook/rag/query as a standalone mode.",
    )
    parser.add_argument(
        "--collection",
        default=DEFAULT_FILE_COLLECTION,
        help=(
            "Collection name used with --ingest-path or --query "
            f"(default: {DEFAULT_FILE_COLLECTION})"
        ),
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=3,
        help="Top-K documents to request with --query (default: 3)",
    )
    args = parser.parse_args()

    base_url = args.base_url.rstrip("/")

    # Build a requests session with optional basic auth
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    if args.username and args.password:
        sess.auth = (args.username, args.password)

    print(f"\n{CYAN}n8n RAG API Test Suite{RESET}")
    print(f"{CYAN}Base URL : {base_url}{RESET}")
    print(f"{CYAN}Auth     : {'enabled' if args.username else 'none'}{RESET}")

    if args.ingest_path:
        if args.test != "all" or args.query_text:
            fail("--ingest-path is a standalone mode. Run it without --test or --query.")
            sys.exit(1)
        success = ingest_custom_files(sess, base_url, args.ingest_path, args.collection)
        sys.exit(0 if success else 1)

    if args.query_text:
        if args.test != "all":
            fail("--query is a standalone mode. Run it without --test.")
            sys.exit(1)
        success = run_custom_query(sess, base_url, args.query_text, args.collection, args.top_k)
        sys.exit(0 if success else 1)

    results: dict[str, bool] = {}

    if args.test == "all":
        for name in ALL_TEST_ORDER:
            results[name] = TESTS[name](sess, base_url)
    else:
        results[args.test] = TESTS[args.test](sess, base_url)

    print_summary(results)
    sys.exit(0 if all(results.values()) else 1)


if __name__ == "__main__":
    main()
