param(
    [string]$SettingsPath = (Join-Path $PSScriptRoot "..\templates\ecs-settings.json")
)

$ErrorActionPreference = "Stop"

function Require-Value {
    param(
        [string]$Name,
        $Value
    )

    if ($null -eq $Value -or ($Value -is [string] -and [string]::IsNullOrWhiteSpace($Value))) {
        throw "Missing required value in ecs-settings.json: $Name"
    }
}

function Escape-JsonString {
    param([string]$Value)

    if ($null -eq $Value) {
        return ""
    }

    return (($Value | ConvertTo-Json -Compress) -replace '^"|"$', '')
}

function To-JsonArray {
    param($Value)
    $items = @($Value)

    if ($items.Count -eq 1) {
        return "[" + ($items[0] | ConvertTo-Json -Compress) + "]"
    }

    return ($items | ConvertTo-Json -Compress)
}

$settingsFile = Resolve-Path $SettingsPath
$settings = Get-Content $settingsFile -Raw | ConvertFrom-Json

Require-Value -Name "region" -Value $settings.region
Require-Value -Name "family" -Value $settings.family
Require-Value -Name "taskDefinition" -Value $settings.taskDefinition
Require-Value -Name "serviceName" -Value $settings.serviceName
Require-Value -Name "containerName" -Value $settings.containerName
Require-Value -Name "image" -Value $settings.image
Require-Value -Name "cpu" -Value $settings.cpu
Require-Value -Name "memory" -Value $settings.memory
Require-Value -Name "clusterArn" -Value $settings.clusterArn
Require-Value -Name "executionRoleArn" -Value $settings.executionRoleArn
Require-Value -Name "taskRoleArn" -Value $settings.taskRoleArn
Require-Value -Name "targetGroupArn" -Value $settings.targetGroupArn
Require-Value -Name "logGroup" -Value $settings.logGroup
Require-Value -Name "n8nProtocol" -Value $settings.n8nProtocol
Require-Value -Name "n8nHost" -Value $settings.n8nHost
Require-Value -Name "webhookUrl" -Value $settings.webhookUrl
Require-Value -Name "editorBaseUrl" -Value $settings.editorBaseUrl
Require-Value -Name "opensearchEndpoint" -Value $settings.opensearchEndpoint
Require-Value -Name "opensearchIndex" -Value $settings.opensearchIndex
Require-Value -Name "openAiLlmModel" -Value $settings.openAiLlmModel
Require-Value -Name "openAiEmbeddingModel" -Value $settings.openAiEmbeddingModel
Require-Value -Name "openAiEmbeddingDimensions" -Value $settings.openAiEmbeddingDimensions

Require-Value -Name "database.host" -Value $settings.database.host
Require-Value -Name "database.port" -Value $settings.database.port
Require-Value -Name "database.name" -Value $settings.database.name
Require-Value -Name "database.user" -Value $settings.database.user
Require-Value -Name "database.schema" -Value $settings.database.schema

Require-Value -Name "secrets.n8nEncryptionKeyArn" -Value $settings.secrets.n8nEncryptionKeyArn
Require-Value -Name "secrets.openAiApiKeyArn" -Value $settings.secrets.openAiApiKeyArn
Require-Value -Name "secrets.openSearchAuthHeaderArn" -Value $settings.secrets.openSearchAuthHeaderArn
Require-Value -Name "secrets.dbPasswordArn" -Value $settings.secrets.dbPasswordArn

if (-not $settings.subnetIds -or $settings.subnetIds.Count -lt 1) {
    throw "ecs-settings.json must contain at least one subnet ID."
}

if (-not $settings.securityGroupIds -or $settings.securityGroupIds.Count -lt 1) {
    throw "ecs-settings.json must contain at least one security group ID."
}

$templatesDir = Split-Path $settingsFile -Parent
$packageDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$taskTemplatePath = Join-Path $templatesDir "ecs-task-definition.template.json"
$serviceTemplatePath = Join-Path $templatesDir "ecs-service.template.json"

$taskTemplate = Get-Content $taskTemplatePath -Raw
$serviceTemplate = Get-Content $serviceTemplatePath -Raw

$n8nSecureCookie =
    if ($settings.PSObject.Properties.Name -contains "n8nSecureCookie" -and -not [string]::IsNullOrWhiteSpace([string]$settings.n8nSecureCookie)) {
        [string]$settings.n8nSecureCookie
    } elseif ([string]$settings.n8nProtocol -eq "https") {
        "true"
    } else {
        "false"
    }

$replacements = [ordered]@{
    "__FAMILY__" = Escape-JsonString $settings.family
    "__TASK_DEFINITION__" = Escape-JsonString $settings.taskDefinition
    "__SERVICE_NAME__" = Escape-JsonString $settings.serviceName
    "__CONTAINER_NAME__" = Escape-JsonString $settings.containerName
    "__IMAGE__" = Escape-JsonString $settings.image
    "__CPU__" = Escape-JsonString ([string]$settings.cpu)
    "__MEMORY__" = Escape-JsonString ([string]$settings.memory)
    "__CONTAINER_PORT__" = [string]$settings.containerPort
    "__DESIRED_COUNT__" = [string]$settings.desiredCount
    "__ASSIGN_PUBLIC_IP__" = Escape-JsonString ([string]$settings.assignPublicIp)
    "__CLUSTER_ARN__" = Escape-JsonString $settings.clusterArn
    "__EXECUTION_ROLE_ARN__" = Escape-JsonString $settings.executionRoleArn
    "__TASK_ROLE_ARN__" = Escape-JsonString $settings.taskRoleArn
    "__TARGET_GROUP_ARN__" = Escape-JsonString $settings.targetGroupArn
    "__LOG_GROUP__" = Escape-JsonString $settings.logGroup
    "__REGION__" = Escape-JsonString $settings.region
    "__N8N_PROTOCOL__" = Escape-JsonString $settings.n8nProtocol
    "__N8N_HOST__" = Escape-JsonString $settings.n8nHost
    "__WEBHOOK_URL__" = Escape-JsonString $settings.webhookUrl
    "__EDITOR_BASE_URL__" = Escape-JsonString $settings.editorBaseUrl
    "__N8N_SECURE_COOKIE__" = Escape-JsonString $n8nSecureCookie
    "__DB_HOST__" = Escape-JsonString $settings.database.host
    "__DB_PORT__" = Escape-JsonString ([string]$settings.database.port)
    "__DB_NAME__" = Escape-JsonString $settings.database.name
    "__DB_USER__" = Escape-JsonString $settings.database.user
    "__DB_SCHEMA__" = Escape-JsonString $settings.database.schema
    "__OPENSEARCH_ENDPOINT__" = Escape-JsonString $settings.opensearchEndpoint
    "__OPENSEARCH_INDEX__" = Escape-JsonString $settings.opensearchIndex
    "__OPENAI_LLM_MODEL__" = Escape-JsonString $settings.openAiLlmModel
    "__OPENAI_EMBEDDING_MODEL__" = Escape-JsonString $settings.openAiEmbeddingModel
    "__OPENAI_EMBEDDING_DIMENSIONS__" = Escape-JsonString ([string]$settings.openAiEmbeddingDimensions)
    "__TOOL_WEB_SEARCH_ENABLED__" = Escape-JsonString ([string]$settings.toolWebSearchEnabled)
    "__TOOL_CALCULATOR_ENABLED__" = Escape-JsonString ([string]$settings.toolCalculatorEnabled)
    "__TOOL_DATETIME_ENABLED__" = Escape-JsonString ([string]$settings.toolDatetimeEnabled)
    "__N8N_ENCRYPTION_KEY_SECRET_ARN__" = Escape-JsonString $settings.secrets.n8nEncryptionKeyArn
    "__OPENAI_API_KEY_SECRET_ARN__" = Escape-JsonString $settings.secrets.openAiApiKeyArn
    "__OPENSEARCH_AUTH_HEADER_SECRET_ARN__" = Escape-JsonString $settings.secrets.openSearchAuthHeaderArn
    "__DB_PASSWORD_SECRET_ARN__" = Escape-JsonString $settings.secrets.dbPasswordArn
    "__SUBNET_IDS_JSON__" = To-JsonArray -Value @($settings.subnetIds)
    "__SECURITY_GROUP_IDS_JSON__" = To-JsonArray -Value @($settings.securityGroupIds)
}

foreach ($pair in $replacements.GetEnumerator()) {
    $taskTemplate = $taskTemplate.Replace($pair.Key, $pair.Value)
    $serviceTemplate = $serviceTemplate.Replace($pair.Key, $pair.Value)
}

$taskOut = Join-Path $packageDir "ecs-task-definition.generated.json"
$serviceOut = Join-Path $packageDir "ecs-service.generated.json"

$encoding = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($taskOut, $taskTemplate.TrimEnd("`r", "`n") + "`n", $encoding)
[System.IO.File]::WriteAllText($serviceOut, $serviceTemplate.TrimEnd("`r", "`n") + "`n", $encoding)

Write-Host "Generated ECS assets:" -ForegroundColor Green
Write-Host "  $taskOut"
Write-Host "  $serviceOut"
