param(
    [Parameter(Mandatory = $true)]
    [string]$Username,

    [Parameter(Mandatory = $true)]
    [string]$Password
)

$pair = "{0}:{1}" -f $Username, $Password
$bytes = [System.Text.Encoding]::UTF8.GetBytes($pair)
$token = [System.Convert]::ToBase64String($bytes)

Write-Output ("Basic " + $token)
