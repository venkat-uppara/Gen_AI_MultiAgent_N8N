import argparse
import json
import ssl
import sys
import urllib.error
import urllib.request


def request_json(method: str, url: str, headers: dict[str, str], body: dict | None, insecure: bool):
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")

    request = urllib.request.Request(url=url, method=method, headers=headers, data=data)
    context = ssl._create_unverified_context() if insecure else None

    with urllib.request.urlopen(request, context=context, timeout=30) as response:
        raw = response.read().decode("utf-8")
        return response.status, json.loads(raw) if raw else {}


def build_index_payload(dimensions: int) -> dict:
    return {
        "settings": {
            "index": {
                "knn": True,
                "knn.algo_param.ef_search": 512,
                "number_of_shards": 1,
                "number_of_replicas": 1,
            }
        },
        "mappings": {
            "properties": {
                "content": {"type": "text"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": dimensions,
                    "method": {
                        "name": "hnsw",
                        "space_type": "cosinesimil",
                        "engine": "nmslib",
                        "parameters": {
                            "ef_construction": 512,
                            "m": 16,
                        },
                    },
                },
                "document_id": {"type": "keyword"},
                "collection": {"type": "keyword"},
                "chunk_index": {"type": "integer"},
                "metadata": {"type": "object", "enabled": True, "dynamic": True},
                "indexed_at": {"type": "date"},
            }
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Create the RAG OpenSearch index if it does not exist.")
    parser.add_argument("--endpoint", required=True, help="OpenSearch endpoint, for example https://search-domain.region.es.amazonaws.com")
    parser.add_argument("--auth-header", required=True, help="Basic auth header value, including the 'Basic ' prefix")
    parser.add_argument("--index", default="rag-documents", help="Index name to create")
    parser.add_argument("--dimensions", type=int, default=1024, help="Embedding vector dimension")
    parser.add_argument("--insecure", action="store_true", help="Disable TLS verification")
    args = parser.parse_args()

    endpoint = args.endpoint.rstrip("/")
    index_url = f"{endpoint}/{args.index}"
    headers = {
        "Authorization": args.auth_header,
        "Content-Type": "application/json",
    }

    try:
        status, _ = request_json("GET", index_url, headers, None, args.insecure)
        if status == 200:
            print(f"Index '{args.index}' already exists.")
            return 0
    except urllib.error.HTTPError as error:
        if error.code != 404:
            detail = error.read().decode("utf-8", errors="replace")
            print(f"Failed to inspect index '{args.index}': {error.code} {detail}", file=sys.stderr)
            return 1
    except Exception as error:  # pragma: no cover - defensive path
        print(f"Failed to inspect index '{args.index}': {error}", file=sys.stderr)
        return 1

    payload = build_index_payload(args.dimensions)

    try:
        status, response = request_json("PUT", index_url, headers, payload, args.insecure)
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        print(f"Failed to create index '{args.index}': {error.code} {detail}", file=sys.stderr)
        return 1
    except Exception as error:  # pragma: no cover - defensive path
        print(f"Failed to create index '{args.index}': {error}", file=sys.stderr)
        return 1

    if status not in (200, 201):
        print(f"Unexpected response while creating index '{args.index}': {status}", file=sys.stderr)
        return 1

    print(json.dumps({
        "success": True,
        "index": args.index,
        "dimensions": args.dimensions,
        "response": response,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
