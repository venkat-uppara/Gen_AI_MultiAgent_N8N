# AWS_PAAS Terraform From Zero

This guide is the most automated path in the `AWS_PAAS` pack.

It creates the AWS infrastructure for the current n8n Community Edition Agentic AI RAG deployment with Terraform and keeps the manual work on your side as small as possible.

## What Terraform Creates For You

The Terraform pack in `terraform/` creates:

- VPC
- two public subnets across two Availability Zones
- internet gateway and route table
- security groups
- Application Load Balancer
- ECS cluster, task definition, and Fargate service
- CloudWatch log group
- Amazon RDS PostgreSQL
- Amazon OpenSearch Service
- Secrets Manager secrets
- generated passwords and the n8n encryption key
- the runtime configuration for n8n to create the OpenSearch vector index on first ingest

## What You Still Do Manually

Terraform does not finish the n8n application bootstrap itself.

After `terraform apply`, you still do these steps:

1. open the n8n URL from Terraform output
2. complete the first owner setup screen
3. import the three workflow JSON files from `workflows/`
4. activate the three workflows
5. run the AWS test suite from this folder

That is the remaining manual part.

## Expected Effort From Your Side

If your AWS credentials are already working, your side is usually:

- one variables file
- `terraform init`
- `terraform plan`
- `terraform apply`
- one short browser setup pass in n8n
- one test command

## Prerequisites

Have these ready on your machine:

- Terraform
- AWS CLI
- Python 3
- an AWS account with permission to create ECS, ALB, RDS, OpenSearch, IAM, Secrets Manager, VPC, and CloudWatch resources

You also need:

- your OpenAI API key
- your current public IP in CIDR form, for example `203.0.113.10/32`

## Cost Reminder

This deployment is billable.

At minimum, expect charges for:

- ECS/Fargate
- ALB
- RDS PostgreSQL
- Amazon OpenSearch Service
- CloudWatch Logs
- OpenAI API usage

## Step 1: Authenticate AWS

From PowerShell, confirm you are using the correct AWS account and region:

```powershell
aws sts get-caller-identity
aws configure get region
```

If needed, set the region explicitly for the current shell:

```powershell
$env:AWS_REGION = "us-east-1"
```

## Step 2: Prepare The Variables File

Go into the Terraform folder:

```powershell
Set-Location .\terraform
```

Copy the example variables file:

```powershell
Copy-Item .\terraform.tfvars.example .\terraform.tfvars
```

Edit `terraform.tfvars` and set at least:

- `aws_region`
- `allowed_cidr_blocks`
- `openai_api_key`

Everything else already has a working default for a first deployment.

## Step 3: Initialize Terraform

Run:

```powershell
terraform init
```

## Step 4: Review The Plan

Run:

```powershell
terraform plan
```

Look especially at:

- ALB name
- ECS service name
- RDS instance
- OpenSearch domain
- estimated billable resources

## Step 5: Apply The Stack

Run:

```powershell
terraform apply
```

Terraform will create the infrastructure and leave the OpenSearch index bootstrap to the n8n ingestion workflow running inside AWS.

This can take a while. OpenSearch and RDS are usually the slowest resources.

## Step 6: Read The Outputs

After the apply completes, run:

```powershell
terraform output
```

The most important outputs are:

- `n8n_base_url`
- `alb_dns_name`
- `rag_health_url`
- `cluster_name`
- `service_name`

If you want only the base URL:

```powershell
terraform output -raw n8n_base_url
```

## Step 7: Complete The First n8n Login

Open the `n8n_base_url` output in your browser.

On the first run, n8n shows the owner setup screen.

Complete that screen and log in.

## Step 8: Import The Workflows

Inside n8n, import these three files from the `workflows/` folder in `AWS_PAAS`:

1. `01-document-ingestion.json`
2. `02-rag-query.json`
3. `03-health-check.json`

Then activate all three workflows.

These workflow files already expect runtime values from the ECS task environment, so there is no extra in-app credential creation step for this pack.

## Step 9: Run The AWS Tests

Go back to the `AWS_PAAS` folder and run:

```powershell
Set-Location ..
python .\scripts\test_api.py --base-url http://YOUR_ALB_DNS_NAME --test all
```

You can replace `http://YOUR_ALB_DNS_NAME` with the exact `n8n_base_url` output from Terraform.

The first successful ingest run creates the `rag-documents` index from inside n8n. Because the OpenSearch domain is private inside the VPC, Terraform does not try to create that index directly from your laptop.

## The Minimal Manual Checklist

If you want the shortest possible summary of what you still do after the Terraform files exist, it is this:

1. put your OpenAI key and IP CIDR in `terraform.tfvars`
2. run `terraform init`
3. run `terraform apply`
4. open the output URL
5. finish owner setup
6. import and activate the three workflows
7. run `python .\scripts\test_api.py --base-url <output-url> --test all`

## Why Workflow Import Is Still Manual

The infrastructure is easy to automate with Terraform.

The n8n application bootstrap is the part that is intentionally left simple:

- owner creation happens in the app
- workflow import and activation are done after you can sign in

That keeps the Terraform layer stable and avoids mixing infra provisioning with brittle UI bootstrap logic.

## Destroy The Stack Later

If you want to remove everything created by this Terraform pack:

```powershell
terraform destroy
```

## Important Note About Terraform State

This Terraform path stores sensitive values in state.

For a first deployment from your machine, that is acceptable if the machine is trusted.

If you later want a team-safe or longer-lived setup, move the Terraform state to a remote backend before repeated use.
