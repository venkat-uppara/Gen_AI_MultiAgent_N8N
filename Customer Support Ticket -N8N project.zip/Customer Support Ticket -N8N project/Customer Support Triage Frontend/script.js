const WEBHOOK_URL = 'https://grok26.app.n8n.cloud/webhook/support-ticket';

const form = document.getElementById('ticket-form');
const formView = document.getElementById('form-view');
const successView = document.getElementById('success-view');
const submitBtn = document.getElementById('submit-btn');
const btnLoader = document.getElementById('btn-loader');
const btnIcon = document.getElementById('btn-icon');
const btnText = document.getElementById('btn-text');
const statusError = document.getElementById('status-error');

// Form inputs
const inputs = {
    name: document.getElementById('name'),
    email: document.getElementById('email'),
    subject: document.getElementById('subject'),
    message: document.getElementById('message')
};

// Error displays
const errors = {
    name: document.getElementById('name-error'),
    email: document.getElementById('email-error'),
    subject: document.getElementById('subject-error'),
    message: document.getElementById('message-error')
};

// Demo data
const demoData = {
    billing: {
        name: 'Jane Smith',
        email: 'jane.smith@example.com',
        subject: 'Overcharged for subscription',
        message: 'I noticed a double charge on my bank statement for the monthly subscription. Please help me with a refund for the extra amount.'
    },
    tech: {
        name: 'Alex Rivera',
        email: 'alex.r@techcorp.io',
        subject: 'Dashboard not loading in Safari',
        message: 'When I try to access the analytics dashboard using Safari 17.2, the page remains blank and shows a JS error in console: "Unexpected token \'.\'".'
    },
    general: {
        name: 'Mike Johnson',
        email: 'mike.j@gmail.com',
        subject: 'Inquiry about API limits',
        message: 'I am planning to upgrade my plan and wanted to know the specific rate limits for the Enterprise API tier. Is there a sandbox environment for testing?'
    }
};

/**
 * Pre-fill form with demo data
 */
function fillDemo(type) {
    const data = demoData[type];
    if (!data) return;

    inputs.name.value = data.name;
    inputs.email.value = data.email;
    inputs.subject.value = data.subject;
    inputs.message.value = data.message;

    // Clear any existing errors
    Object.values(errors).forEach(err => err.style.display = 'none');
    statusError.textContent = '';
}

/**
 * Validate email format
 */
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Handle form validation
 */
function validate() {
    let isValid = true;

    // Name
    if (inputs.name.value.trim().length < 2) {
        errors.name.style.display = 'block';
        isValid = false;
    } else {
        errors.name.style.display = 'none';
    }

    // Email
    if (!isValidEmail(inputs.email.value)) {
        errors.email.style.display = 'block';
        isValid = false;
    } else {
        errors.email.style.display = 'none';
    }

    // Subject
    if (inputs.subject.value.trim().length < 5) {
        errors.subject.style.display = 'block';
        isValid = false;
    } else {
        errors.subject.style.display = 'none';
    }

    // Message
    if (inputs.message.value.trim().length < 10) {
        errors.message.style.display = 'block';
        isValid = false;
    } else {
        errors.message.style.display = 'none';
    }

    return isValid;
}

/**
 * Reset form to initial state
 */
function resetForm() {
    form.reset();
    formView.style.display = 'block';
    successView.style.display = 'none';
    statusError.textContent = '';

    // Clear icons from previous state
    lucide.createIcons();
}

/**
 * Handle form submission
 */
form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!validate()) return;

    // Set loading state
    setLoading(true);
    statusError.textContent = '';

    const payload = {
        name: inputs.name.value.trim(),
        email: inputs.email.value.trim(),
        subject: inputs.subject.value.trim(),
        message: inputs.message.value.trim()
    };

    try {
        const response = await fetch(WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error('Server returned non-JSON response');
        }

        const data = await response.json();

        if (response.ok && data.success) {
            showSuccess(data);
        } else {
            throw new Error(data.message || 'Failed to submit ticket');
        }
    } catch (error) {
        console.error('Submission Error:', error);
        statusError.textContent = `Error: ${error.message}. Please try again.`;
    } finally {
        setLoading(false);
    }
});

/**
 * Toggle loading state on button
 */
function setLoading(isNavbarLoading) {
    if (isNavbarLoading) {
        submitBtn.disabled = true;
        btnLoader.style.display = 'block';
        btnIcon.style.display = 'none';
        btnText.textContent = 'Submitting...';
    } else {
        submitBtn.disabled = false;
        btnLoader.style.display = 'none';
        btnIcon.style.display = 'block';
        btnText.textContent = 'Send Ticket';
    }
}

/**
 * Handle success state
 */
function showSuccess(data) {
    // Populate success view
    document.getElementById('res-id').textContent = data.ticket_id;
    document.getElementById('res-summary').textContent = data.summary;

    // Set category badge
    const catContainer = document.getElementById('res-category');
    const category = data.category.toUpperCase();
    catContainer.innerHTML = `<span class="badge badge-${category.toLowerCase()}">${category}</span>`;

    // Set priority
    const priContainer = document.getElementById('res-priority');
    const priority = data.priority.toLowerCase();
    priContainer.innerHTML = `<span class="priority-${priority}">${data.priority.toUpperCase()}</span>`;

    // Swap views
    formView.style.display = 'none';
    successView.style.display = 'block';

    // Refresh icons in success view
    lucide.createIcons();

    // Fire confetti!
    confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#ec4899', '#8b5cf6', '#10b981']
    });
}
