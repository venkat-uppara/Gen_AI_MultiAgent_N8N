const WEBHOOK_URL = 'https://grok26.app.n8n.cloud/webhook/support-ticket';

const form = document.getElementById('ticket-form');
const submitBtn = document.getElementById('submit-btn');
const formSection = document.getElementById('form-section');
const successSection = document.getElementById('success-section');
const toastContainer = document.getElementById('toast-container');
const fillSampleBtn = document.getElementById('fill-sample');
const resetBtn = document.getElementById('reset-btn');

// Sample data for testing
const sampleData = {
    name: "Alex Johnson",
    email: "alex.j@example.com",
    subject: "Cannot access billing dashboard",
    message: "I am trying to view my recent invoices but the page keeps showing a 404 error. This started happening after the maintenance window yesterday. Please fix this as I need to submit my expenses by end of day."
};

fillSampleBtn.addEventListener('click', () => {
    form.name.value = sampleData.name;
    form.email.value = sampleData.email;
    form.subject.value = sampleData.subject;
    form.message.value = sampleData.message;
    
    // Clear any existing errors
    const inputs = form.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.classList.remove('error');
        const errorSpan = document.getElementById(`${input.id}-error`);
        if (errorSpan) errorSpan.style.display = 'none';
    });
});

resetBtn.addEventListener('click', () => {
    form.reset();
    successSection.classList.add('hidden');
    formSection.classList.remove('hidden');
});

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);

    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    try {
        const response = await fetch(WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.success) {
            showSuccess(data);
            triggerConfetti();
        } else {
            showToast(data.message || 'Submission failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Submission error:', error);
        showToast('Network error or server unavailable. Please try again later.', 'error');
    } finally {
        setLoading(false);
    }
});

function validateForm() {
    let isValid = true;
    const inputs = [
        { id: 'name', validate: (v) => v.trim().length > 0 },
        { id: 'email', validate: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) },
        { id: 'subject', validate: (v) => v.trim().length > 0 },
        { id: 'message', validate: (v) => v.trim().length > 0 }
    ];

    inputs.forEach(input => {
        const element = document.getElementById(input.id);
        const errorSpan = document.getElementById(`${input.id}-error`);
        
        if (!input.validate(element.value)) {
            element.classList.add('error');
            errorSpan.style.display = 'block';
            isValid = false;
        } else {
            element.classList.remove('error');
            errorSpan.style.display = 'none';
        }
    });

    return isValid;
}

function setLoading(isLoading) {
    if (isLoading) {
        submitBtn.disabled = true;
        submitBtn.classList.add('submitting');
    } else {
        submitBtn.disabled = false;
        submitBtn.classList.remove('submitting');
    }
}

function showSuccess(data) {
    formSection.classList.add('hidden');
    successSection.classList.remove('hidden');

    document.getElementById('res-ticket-id').textContent = data.ticket_id || 'TKT-PENDING';
    
    const categoryEl = document.getElementById('res-category');
    categoryEl.textContent = data.category || 'GENERAL';
    categoryEl.className = `detail-value badge badge-${(data.category || 'general').toLowerCase()}`;

    const priorityEl = document.getElementById('res-priority');
    priorityEl.textContent = data.priority || 'LOW';
    priorityEl.className = `detail-value badge badge-${(data.priority || 'low').toLowerCase()}`;

    document.getElementById('res-summary').textContent = data.summary || 'Ticket received.';
    document.getElementById('success-msg').textContent = data.message || 'Confirmation message sent.';
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

function triggerConfetti() {
    confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#a855f7', '#10b981']
    });
}
