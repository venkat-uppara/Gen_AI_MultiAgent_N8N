from glove import Corpus, Glove
import pandas as pd

# Sample sentences for training
sentences = [
    ["it", "is", "a", "flower"],
    ["the", "weather", "is", "nice"],
    ["the", "flower", "blooms"],
    ["it", "is", "sunny"],
    ["the", "sun", "is", "bright"]
]

# Create a corpus from the sentences
corpus = Corpus()
corpus.fit(sentences, window=5)

# Print the shape of the co-occurrence matrix
print("Co-occurrence matrix shape:", corpus.matrix.shape)

# Create and train the GloVe model
glove = Glove(no_components=10, learning_rate=0.05)
glove.fit(corpus.matrix, epochs=3000, no_threads=4, verbose=True)

# Check if the model has been trained successfully
if glove.word_vectors is not None:
    word_vectors = glove.word_vectors
    words = list(corpus.dictionary.keys())
    # Print the word vectors with their corresponding words
    print(pd.DataFrame(dict(zip(words, word_vectors))))
else:
    print("The GloVe model has not been trained successfully.")