"""
==========================================================================
  STEP 2: Research Assistant Agent — Tools + ReAct Loop + Memory
==========================================================================

This builds on Step 1 by adding:
  - TOOLS:    Tavily web search + Wikipedia lookup
  - REACT LOOP: Conditional edges that let the LLM decide to call tools
                 or return a final answer
  - MEMORY:   MemorySaver checkpointer for chat history persistence

Graph structure:
               ┌──────────────┐
               │    START      │
               └──────┬───────┘
                      │
                      ▼
               ┌──────────────┐
        ┌─────►│    agent      │◄─────┐
        │      │  (LLM brain)  │      │
        │      └──────┬───────┘      │
        │             │               │
        │    ┌────────┴────────┐      │
        │    │  should_continue │      │
        │    └────────┬────────┘      │
        │         ╱        ╲          │
        │   "tools"      "end"        │
        │       │            │        │
        │       ▼            ▼        │
        │  ┌─────────┐  ┌────────┐   │
        └──│  tools   │  │  END   │   │
           │(executor)│  └────────┘   │
           └─────────┘                │
                                      │

  The LLM decides: call a tool → loop back, or final answer → end.

Run this file:
  python step2_research_agent.py
==========================================================================
"""

import os
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

# =====================================================================
# 1. IMPORTS
# =====================================================================
from typing import Annotated
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver

from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper


# =====================================================================
# 2. DEFINE TOOLS — What the agent can do
# =====================================================================
# Tool 1: Web Search (for current, real-time information)
# Tavily is designed specifically for AI agents — returns clean results.
# Free tier: 1,000 searches/month at tavily.com

tavily_search = TavilySearchResults(
    max_results=3,
    description=(
        "Search the web for current, up-to-date information. "
        "Use this for recent events, statistics, news, trends, "
        "and any information that may have changed recently."
    ),
)

# Tool 2: Wikipedia (for background knowledge and definitions)
# Uses the Wikipedia API — no API key needed, completely free.

wikipedia = WikipediaQueryRun(
    api_wrapper=WikipediaAPIWrapper(
        top_k_results=2,
        doc_content_chars_max=2000,  # Limit to avoid token overflow
    ),
    description=(
        "Look up background information, definitions, historical context, "
        "and well-established knowledge on Wikipedia. Use for topics that "
        "need foundational understanding rather than breaking news."
    ),
)

# Combine all tools into a list
tools = [tavily_search, wikipedia]

# --- Inspect tools (run this section to see what the LLM receives) ---
print("=" * 60)
print("  Registered Tools:")
print("=" * 60)
for tool in tools:
    print(f"\n  Name:        {tool.name}")
    print(f"  Description: {tool.description[:80]}...")
print()


# =====================================================================
# 3. DEFINE STATE — What data flows through the graph
# =====================================================================
class AgentState(TypedDict):
    messages: Annotated[list, add_messages]


# =====================================================================
# 4. CREATE THE LLM WITH TOOLS BOUND
# =====================================================================
# bind_tools() tells the LLM about available tools.
# The LLM can now output structured tool_calls in its response.

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
llm_with_tools = llm.bind_tools(tools)

# System prompt: defines the agent's role, rules, and behavior
SYSTEM_PROMPT = """You are a thorough Research Assistant agent. Your job is to
help users research topics by searching the web and looking up background
information.

GUIDELINES:
- For current events, statistics, trends, or recent news: use tavily_search_results_json
- For definitions, history, or established knowledge: use wikipedia
- Always search at least once before answering — do NOT rely solely on your
  training data
- If a search returns poor or irrelevant results, try rephrasing the query
- Cross-reference information from multiple sources when possible
- When you have enough information, compile a clear, well-structured answer

OUTPUT FORMAT:
When presenting your final research, use this structure:
1. Key Findings (the most important points, as bullet points)
2. Background Context (foundational info the reader needs)
3. Recent Developments (what's new or changing)
4. Sources (list the sources you consulted)

Always cite your sources. Never make up information."""


# =====================================================================
# 5. DEFINE NODES — The processing steps
# =====================================================================

def agent(state: AgentState):
    """
    The BRAIN of the agent — the 'Think' step in ReAct.

    Takes the current state (all messages so far), calls the LLM,
    and returns the LLM's response. The response may contain:
      - tool_calls: the LLM wants to use a tool (loop continues)
      - content only: the LLM has a final answer (loop ends)
    """
    messages = state["messages"]

    # Prepend system prompt if not already present
    # (We check each time because memory might load a conversation
    #  that already has the system prompt from a previous run)
    if not any(
        isinstance(m, SystemMessage) or getattr(m, "type", "") == "system"
        for m in messages
    ):
        messages = [SystemMessage(content=SYSTEM_PROMPT)] + messages

    # Call the LLM with tools available
    response = llm_with_tools.invoke(messages)

    return {"messages": [response]}


# ToolNode is a LangGraph built-in that automatically:
#   1. Reads tool_calls from the last message
#   2. Executes each tool with the provided arguments
#   3. Returns ToolMessage objects with the results
tool_node = ToolNode(tools=tools)


# =====================================================================
# 6. DEFINE ROUTING — The conditional edge
# =====================================================================

def should_continue(state: AgentState) -> str:
    """
    The DECISION POINT — determines if the agent loop continues.

    After the agent (LLM) responds, check:
      - Did it make tool_calls? → route to "tools" (continue the loop)
      - No tool_calls? → route to "end" (return final answer)

    This is what makes it an AGENT (dynamic control flow) rather than
    a CHAIN (fixed control flow).
    """
    last_message = state["messages"][-1]

    # Check if the LLM wants to call any tools
    if last_message.tool_calls:
        return "tools"

    # No tool calls = final answer
    return "end"


# =====================================================================
# 7. BUILD THE GRAPH — Wire everything together
# =====================================================================

graph_builder = StateGraph(AgentState)

# Add nodes (the processing steps)
graph_builder.add_node("agent", agent)        # The LLM "brain"
graph_builder.add_node("tools", tool_node)    # Tool executor

# Add edges (the connections)
graph_builder.add_edge(START, "agent")        # Start → agent

# CONDITIONAL EDGE: This is the heart of the agent!
# After "agent" runs, call should_continue() to decide the next step.
graph_builder.add_conditional_edges(
    "agent",               # Source node
    should_continue,       # Router function
    {
        "tools": "tools",  # If should_continue returns "tools" → go to tools node
        "end": END,        # If should_continue returns "end" → finish
    },
)

# After tools execute, always go back to agent (the loop!)
graph_builder.add_edge("tools", "agent")

# Add memory — MemorySaver stores state between invocations
# This enables short-term (chat) memory: the agent remembers
# previous messages when you use the same thread_id.
memory = MemorySaver()

# Compile the graph with memory
graph = graph_builder.compile(checkpointer=memory)

print("Agent graph compiled successfully!")
print("Graph nodes:", list(graph.get_graph().nodes.keys()))


# =====================================================================
# 8. TEST THE AGENT
# =====================================================================
if __name__ == "__main__":

    # Configuration: thread_id groups messages into a conversation.
    # Same thread_id = same conversation (memory carries over).
    # Different thread_id = fresh conversation.
    config = {"configurable": {"thread_id": "research-session-1"}}
    
    # --- Test 1: Basic Research ---
    print("\n" + "=" * 60)
    print("  Test 1: Basic Research Query")
    print("=" * 60)

    t1_start = datetime.now()
    result = graph.invoke(
        {"messages": [HumanMessage(content="What is LangGraph and why is it useful for building AI agents?")]},
        config=config,
    )
    t1_end = datetime.now()

    # Print the final answer
    print(f"\nFinal Answer:\n{result['messages'][-1].content}")

    # Show how many messages were generated (includes tool calls/results)
    print(f"\n--- Total messages in conversation: {len(result['messages'])} ---")
    for i, msg in enumerate(result["messages"]):
        msg_type = msg.type if hasattr(msg, "type") else type(msg).__name__
        has_tools = hasattr(msg, "tool_calls") and msg.tool_calls
        preview = msg.content[:60] if msg.content else "(tool call)"
        print(f"  [{i}] {msg_type:10s} | {'TOOL CALL' if has_tools else preview}...")

    print(f"\n[Test 1 | Start: {t1_start:%Y-%m-%d %H:%M:%S} | End: {t1_end:%Y-%m-%d %H:%M:%S} | Elapsed: {(t1_end - t1_start).total_seconds():.2f}s]")

    # --- Test 2: Follow-up (tests memory) ---
    print("\n" + "=" * 60)
    print("  Test 2: Follow-up Question (Tests Memory)")
    print("=" * 60)

    t2_start = datetime.now()
    result = graph.invoke(
        {"messages": [HumanMessage(content="How does it compare to other agent frameworks like CrewAI?")]},
        config=config,  # Same thread_id — agent remembers context!
    )
    t2_end = datetime.now()

    print(f"\nFinal Answer:\n{result['messages'][-1].content}")
    print(f"\n[Test 2 | Start: {t2_start:%Y-%m-%d %H:%M:%S} | End: {t2_end:%Y-%m-%d %H:%M:%S} | Elapsed: {(t2_end - t2_start).total_seconds():.2f}s]")

    # --- Test 3: New conversation (different thread) ---
    print("\n" + "=" * 60)
    print("  Test 3: New Conversation (Different Thread)")
    print("=" * 60)

    config2 = {"configurable": {"thread_id": "research-session-2"}}

    t3_start = datetime.now()
    result = graph.invoke(
        {"messages": [HumanMessage(content="What are the latest developments in AI regulation in 2024?")]},
        config=config2,  # New thread = fresh conversation, no memory of previous
    )
    t3_end = datetime.now()

    print(f"\nFinal Answer:\n{result['messages'][-1].content}")
    print(f"\n[Test 3 | Start: {t3_start:%Y-%m-%d %H:%M:%S} | End: {t3_end:%Y-%m-%d %H:%M:%S} | Elapsed: {(t3_end - t3_start).total_seconds():.2f}s]")

    print("\n" + "=" * 60)
    print("  All tests complete!")
    print("  Next: step3_interactive_session.py (chat interface)")
    print("=" * 60)
