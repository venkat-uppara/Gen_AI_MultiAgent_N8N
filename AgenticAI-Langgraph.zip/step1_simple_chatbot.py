"""
==========================================================================
  STEP 1: Your First LangGraph — A Simple Chatbot (No Tools)
==========================================================================

This is the simplest possible LangGraph application: a chatbot that
calls an LLM and returns the response. No tools, no loops, no memory.

Purpose: Understand the core LangGraph concepts:
  - State:  A TypedDict that carries data between nodes
  - Node:   A function that reads state, does work, returns updated state
  - Edge:   A connection between nodes
  - Graph:  The complete workflow: nodes + edges + state

Graph structure:
  START → chatbot → END

Run this file:
  python step1_simple_chatbot.py
==========================================================================
"""

import os
from dotenv import load_dotenv

# Load API keys from .env file
load_dotenv()

# =====================================================================
# 1. IMPORTS
# =====================================================================
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_openai import ChatOpenAI


# =====================================================================
# 2. DEFINE STATE — What data flows through the graph
# =====================================================================
# State is a TypedDict: a Python dictionary with typed keys.
# add_messages is a "reducer" — it APPENDS new messages instead of replacing.
# Without add_messages, each node would overwrite the entire message list.

class State(TypedDict):
    messages: Annotated[list, add_messages]


# =====================================================================
# 3. CREATE THE LLM
# =====================================================================
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,  # Deterministic output for reproducibility
)


# =====================================================================
# 4. DEFINE A NODE — A function that processes state
# =====================================================================
# Every node follows the same pattern:
#   Input:  state (the current State dict)
#   Output: a dict with the state keys to update
#
# The function name becomes the node name in the graph.

def chatbot(state: State):
    """Call the LLM with the current message history and return its response."""
    response = llm.invoke(state["messages"])
    # Return only the keys we want to update
    # add_messages will APPEND this response to the existing messages list
    return {"messages": [response]}


# =====================================================================
# 5. BUILD THE GRAPH
# =====================================================================
# StateGraph takes our State class as a parameter — it knows what
# data structure to expect.

graph_builder = StateGraph(State)

# Add the chatbot node
graph_builder.add_node("chatbot", chatbot)

# Add edges: define the flow
graph_builder.add_edge(START, "chatbot")  # Entry point: start → chatbot
graph_builder.add_edge("chatbot", END)    # Exit point: chatbot → end

# Compile: turns the builder into a runnable graph
graph = graph_builder.compile()

from langgraph.graph import StateGraph

# =====================================================================
# 6. RUN THE GRAPH
# =====================================================================
if __name__ == "__main__":
    print("Graph Rep:")
    graph.get_graph().print_ascii()

    print("=" * 60)
    print("  Step 1: Simple LangGraph Chatbot (No Tools)")
    print("=" * 60)

    # --- Test 1: Basic question ---
    print("\n--- Test 1: Basic Question ---")
    result = graph.invoke({
        "messages": [("user", "What is LangGraph in one sentence?")]
    })
    print(f"User:      What is LangGraph in one sentence?")
    print(f"Assistant: {result['messages'][-1].content}")

    # --- Test 2: Another question ---
    print("\n--- Test 2: Another Question ---")
    result = graph.invoke({
        "messages": [("user", "What are its key components?")]
    })
    print(f"User:      What are the key components of an AI agent?")
    print(f"Assistant: {result['messages'][-1].content}")

    # --- Test 3: Show that there's NO memory ---
    print("\n--- Test 3: Demonstrating No Memory ---")
    print("(Each invoke() is independent — the chatbot doesn't remember)")
    result = graph.invoke({
        "messages": [("user", "What did I just ask you?")]
    })
    print(f"User:      What did I just ask you?")
    print(f"Assistant: {result['messages'][-1].content}")
    print("\n>>> Notice: The chatbot has NO memory of previous questions!")
    print(">>> We'll fix this in step 2 with a checkpointer.")

    # --- Inspect the state ---
    print("\n--- Inspecting the Result ---")
    print(f"Total messages in result: {len(result['messages'])}")
    for i, msg in enumerate(result["messages"]):
        print(f"  Message {i}: type={msg.type}, content={msg.content[:80]}...")

    print("\n" + "=" * 60)
    print("  Next: step2_research_agent.py (add tools + agent loop)")
    print("=" * 60)
