try:
   num = 10
   result = num / 0
   print("Result:", result)
except ZeroDivisionError:
   print("Error: Cannot divide by zero!")
print("The code finished")