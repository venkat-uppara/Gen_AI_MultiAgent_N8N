"""
==========================================================================
  STEP 3: Interactive Research Session — Chat with Your Agent
==========================================================================

This script builds the same research agent as Step 2, but wraps it in
an interactive chat loop with streaming output. You can have a full
multi-turn conversation with the agent.

Features:
  - Interactive input/output loop
  - STREAMING: Watch the agent think step-by-step in real time
  - Chat memory: The agent remembers your conversation
  - Graceful error handling

Run this file:
  python step3_interactive_session.py
==========================================================================
"""

import os
import sys
from dotenv import load_dotenv

load_dotenv()

# =====================================================================
# 1. IMPORTS
# =====================================================================
from typing import Annotated
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver

from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper


# =====================================================================
# 2. VERIFY API KEYS
# =====================================================================
def check_api_keys():
    """Verify that required API keys are set."""
    missing = []
    if not os.getenv("OPENAI_API_KEY"):
        missing.append("OPENAI_API_KEY")
    if not os.getenv("TAVILY_API_KEY"):
        missing.append("TAVILY_API_KEY")

    if missing:
        print("\n[ERROR] Missing API keys:")
        for key in missing:
            print(f"  - {key}")
        print("\nSet them in a .env file or as environment variables:")
        print("  export OPENAI_API_KEY=sk-...")
        print("  export TAVILY_API_KEY=tvly-...")
        sys.exit(1)

check_api_keys()


# =====================================================================
# 3. TOOLS
# =====================================================================
tavily_search = TavilySearchResults(
    max_results=3,
    description=(
        "Search the web for current, up-to-date information. "
        "Use this for recent events, statistics, news, trends, "
        "and any information that may have changed recently."
    ),
)

wikipedia = WikipediaQueryRun(
    api_wrapper=WikipediaAPIWrapper(
        top_k_results=2,
        doc_content_chars_max=2000,
    ),
    description=(
        "Look up background information, definitions, historical context, "
        "and well-established knowledge on Wikipedia. Use for topics that "
        "need foundational understanding rather than breaking news."
    ),
)

tools = [tavily_search, wikipedia]


# =====================================================================
# 4. STATE + LLM + SYSTEM PROMPT
# =====================================================================
class AgentState(TypedDict):
    messages: Annotated[list, add_messages]


llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
llm_with_tools = llm.bind_tools(tools)

SYSTEM_PROMPT = """You are a research assistant agent. Your job is to help users
by looking up information using exactly the right tool for the query — no more.

TOOL SELECTION RULES (pick ONE tool per query unless both are genuinely needed):
- Use wikipedia ONLY for: definitions, concepts, historical facts, biographical info,
  established scientific knowledge, or anything with a stable, well-known answer.
- Use tavily_search_results_json ONLY for: current events, recent news, live statistics,
  prices, trends, or any information that changes over time.
- Use BOTH tools only when a question explicitly has two distinct parts — one needing
  established background AND one needing recent data (e.g. "What is quantum computing
  and what are the latest breakthroughs?").
- Never call a tool just to cross-reference if you already have a sufficient answer.

OUTPUT FORMAT:
When presenting your final answer, use this structure:
1. **Key Findings** (the most important points)
2. **Background Context** (foundational info the reader needs)
3. **Recent Developments** (only if the topic has a time-sensitive dimension)
4. **Sources** (list the sources you consulted)

Always cite your sources. Never make up information.
"""


# =====================================================================
# 5. NODES
# =====================================================================
def agent(state: AgentState):
    """The brain of the agent — decides what to do next."""
    messages = state["messages"]

    if not any(
        isinstance(m, SystemMessage) or getattr(m, "type", "") == "system"
        for m in messages
    ):
        messages = [SystemMessage(content=SYSTEM_PROMPT)] + messages

    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}


tool_node = ToolNode(tools=tools)


# =====================================================================
# 6. ROUTING
# =====================================================================
def should_continue(state: AgentState) -> str:
    """Route to tools (continue) or end (final answer)."""
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return "end"


# =====================================================================
# 7. BUILD GRAPH
# =====================================================================
graph_builder = StateGraph(AgentState)
graph_builder.add_node("agent", agent)
graph_builder.add_node("tools", tool_node)
graph_builder.add_edge(START, "agent")
graph_builder.add_conditional_edges(
    "agent", should_continue, {"tools": "tools", "end": END}
)
graph_builder.add_edge("tools", "agent")

memory = MemorySaver()
graph = graph_builder.compile(checkpointer=memory)


# =====================================================================
# 8. INTERACTIVE CHAT LOOP WITH STREAMING
# =====================================================================
def run_research_session():
    """Run an interactive research session with the agent."""

    # Thread ID for this session — all messages share this conversation
    config = {"configurable": {"thread_id": "interactive-session-1"}}

    # Track tool calls for the session
    total_tool_calls = 0

    print("\n" + "=" * 60)
    print("   Research Assistant Agent")
    print("   Powered by LangGraph + GPT-4o-mini")
    print("=" * 60)
    print()
    print("  Ask me to research any topic! I can search the web and")
    print("  look up background information on Wikipedia.")
    print()
    print("  Commands:")
    print("    'quit' or 'exit'  — End the session")
    print("    'new'             — Start a new conversation (clear memory)")
    print("    'history'         — Show conversation message count")
    print()
    print("-" * 60)

    while True:
        # Get user input
        try:
            user_input = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\nGoodbye!")
            break

        # Handle special commands
        if not user_input:
            continue

        if user_input.lower() in ["quit", "exit", "q"]:
            print(f"\nSession complete! Total tool calls: {total_tool_calls}")
            print("Goodbye!")
            break

        if user_input.lower() == "new":
            # Start a new conversation by changing thread_id
            import uuid
            config = {"configurable": {"thread_id": f"session-{uuid.uuid4().hex[:8]}"}}
            total_tool_calls = 0
            print("\n[New conversation started — memory cleared]")
            continue

        if user_input.lower() == "history":
            # Show how many messages are in the current conversation
            state = graph.get_state(config)
            msg_count = len(state.values.get("messages", []))
            print(f"\n[Current conversation has {msg_count} messages]")
            continue

        # --- Stream the agent's execution ---
        print("\n  Researching...\n")

        step_count = 0
        try:
            for event in graph.stream(
                {"messages": [HumanMessage(content=user_input)]},
                config=config,
                stream_mode="values",
            ):
                last_msg = event["messages"][-1]

                # The LLM decided to call a tool
                if hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
                    for tc in last_msg.tool_calls:
                        step_count += 1
                        total_tool_calls += 1
                        tool_name = tc["name"]
                        tool_args = tc["args"]

                        # Pretty-print the tool call
                        if tool_name == "tavily_search_results_json":
                            print(f"  [{step_count}] Searching web: \"{tool_args.get('query', '')}\"")
                        elif tool_name == "wikipedia":
                            print(f"  [{step_count}] Looking up Wikipedia: \"{tool_args.get('query', '')}\"")
                        else:
                            print(f"  [{step_count}] Calling {tool_name}: {tool_args}")

                # A tool returned results
                elif hasattr(last_msg, "type") and last_msg.type == "tool":
                    content_len = len(last_msg.content) if last_msg.content else 0
                    print(f"       -> Got {content_len:,} chars of results")

            # Print the final answer
            final_answer = event["messages"][-1].content
            print(f"\n{'─' * 60}")
            print(f"\nAssistant:\n{final_answer}")
            print(f"\n{'─' * 60}")
            print(f"  (Used {step_count} tool call{'s' if step_count != 1 else ''} for this query)")

        except Exception as e:
            print(f"\n  [Error] {type(e).__name__}: {e}")
            print("  Try rephrasing your question or check your API keys.")


# =====================================================================
# 9. MAIN
# =====================================================================
if __name__ == "__main__":
    run_research_session()
