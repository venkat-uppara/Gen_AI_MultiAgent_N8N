from openai import OpenAI

client = OpenAI(api_key="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")

# web_search is only supported by the Responses API, not Chat Completions
response = client.responses.create(
    model="gpt-4o-mini",
    tools=[{"type": "web_search_preview"}],
    input="Find the latest news about quantum computing breakthroughs."
)

print(response.output_text)