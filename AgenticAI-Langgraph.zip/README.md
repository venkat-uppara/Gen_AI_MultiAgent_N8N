# Research Assistant Agent — Agentic AI Project

## Session 2: Hands-On Workshop with LangGraph

### Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set your API keys (copy .env.example to .env and fill in)
cp .env.example .env
# Edit .env with your keys:
#   OPENAI_API_KEY=sk-...
#   TAVILY_API_KEY=tvly-...  (free at https://tavily.com)
```

### Project Files (Run in Order)

| File | What It Covers | Duration |
|------|---------------|----------|
| `step1_simple_chatbot.py` | LangGraph basics: State, Node, Edge, Graph | 30 min |
| `step2_research_agent.py` | Full agent: Tools + ReAct loop + Memory | 30 min |
| `step3_interactive_session.py` | Interactive chat with streaming output | 30 min |
| `step4_extensions.py` | Custom tools, safety limits, structured output | 30 min |

### Quick Start

```bash
python step1_simple_chatbot.py   # Start here
python step2_research_agent.py   # Add tools + agent loop
python step3_interactive_session.py  # Chat with your agent!
python step4_extensions.py       # Bonus: custom tools + safety
```

### Architecture

```
User Query
    │
    ▼
┌──────────┐     ┌──────────┐
│  Agent   │────►│  Tools   │
│  (LLM)   │◄────│(Tavily,  │
│          │     │Wikipedia)│
└──────────┘     └──────────┘
    │
    ▼ (when done)
Final Answer
```

### Assignment

Extend the research agent with at least TWO features from step4_extensions.py.
See Session 2 student material for full requirements.
