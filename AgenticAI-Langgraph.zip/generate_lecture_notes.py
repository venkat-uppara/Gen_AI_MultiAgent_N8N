"""
Generate lecture notes Word document for the Agentic AI project.
Run: python generate_lecture_notes.py
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import copy

doc = Document()

# ── Page margins ──────────────────────────────────────────────────────────────
section = doc.sections[0]
section.top_margin    = Cm(2.0)
section.bottom_margin = Cm(2.0)
section.left_margin   = Cm(2.5)
section.right_margin  = Cm(2.5)


# ── Helper: shade a table cell ────────────────────────────────────────────────
def shade_cell(cell, hex_color):
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_color)
    tcPr.append(shd)


# ── Helper: paragraph helpers ─────────────────────────────────────────────────
def add_heading(text, level=1):
    p = doc.add_heading(text, level=level)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in p.runs:
        if level == 1:
            run.font.color.rgb = RGBColor(0x1A, 0x53, 0x76)   # dark blue
        elif level == 2:
            run.font.color.rgb = RGBColor(0x2E, 0x86, 0xAB)   # medium blue
        elif level == 3:
            run.font.color.rgb = RGBColor(0x17, 0x6B, 0x87)   # teal
    return p


def add_body(text, bold=False, italic=False, indent=False):
    p = doc.add_paragraph()
    if indent:
        p.paragraph_format.left_indent = Inches(0.3)
    run = p.add_run(text)
    run.font.size   = Pt(11)
    run.font.bold   = bold
    run.font.italic = italic
    return p


def add_bullet(text, level=0):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.left_indent = Inches(0.3 + level * 0.25)
    run = p.add_run(text)
    run.font.size = Pt(10.5)
    return p


def add_numbered(text):
    p = doc.add_paragraph(style="List Number")
    p.paragraph_format.left_indent = Inches(0.3)
    run = p.add_run(text)
    run.font.size = Pt(10.5)
    return p


def add_code_block(lines):
    """Light-grey shaded table used as a code block."""
    tbl = doc.add_table(rows=1, cols=1)
    tbl.style = "Table Grid"
    cell = tbl.cell(0, 0)
    shade_cell(cell, "F2F2F2")
    cell.paragraphs[0].clear()
    for i, line in enumerate(lines):
        if i == 0:
            para = cell.paragraphs[0]
        else:
            para = cell.add_paragraph()
        run = para.add_run(line)
        run.font.name = "Courier New"
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(0x1E, 0x1E, 0x1E)
    doc.add_paragraph()   # spacing after block


def add_concept_box(title, body_lines):
    """Blue-header info box for theoretical concepts."""
    tbl  = doc.add_table(rows=2, cols=1)
    tbl.style = "Table Grid"
    # header row
    hcell = tbl.cell(0, 0)
    shade_cell(hcell, "1A5376")
    hp = hcell.paragraphs[0]
    hp.clear()
    hr = hp.add_run(f"  {title}")
    hr.font.bold  = True
    hr.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    hr.font.size  = Pt(10.5)
    # body row
    bcell = tbl.cell(1, 0)
    shade_cell(bcell, "EAF4FB")
    for i, line in enumerate(body_lines):
        if i == 0:
            para = bcell.paragraphs[0]
        else:
            para = bcell.add_paragraph()
        run = para.add_run(f"  {line}")
        run.font.size = Pt(10.5)
    doc.add_paragraph()


def divider():
    p = doc.add_paragraph("─" * 72)
    p.runs[0].font.color.rgb = RGBColor(0xCC, 0xCC, 0xCC)
    p.runs[0].font.size = Pt(9)


# ══════════════════════════════════════════════════════════════════════════════
# TITLE PAGE
# ══════════════════════════════════════════════════════════════════════════════
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("Agentic AI with LangGraph")
run.font.size  = Pt(28)
run.font.bold  = True
run.font.color.rgb = RGBColor(0x1A, 0x53, 0x76)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("Lecture Notes — Building a Research Assistant Agent Step by Step")
run.font.size  = Pt(14)
run.font.italic = True
run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

doc.add_paragraph()

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("Tech Stack: Python · LangGraph · LangChain · OpenAI GPT-4o-mini · Tavily · Wikipedia")
run.font.size = Pt(11)

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# INTRODUCTION
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Introduction", 1)
add_body(
    "This course teaches you how to build AI agents — programs that use a Large Language Model (LLM) "
    "as a brain, connect it to real-world tools (web search, calculators, file writers), and run it "
    "inside a graph-based workflow framework called LangGraph."
)
doc.add_paragraph()

add_concept_box("What is an AI Agent?", [
    "An AI agent is a program that:",
    "  1. Perceives input (user message, tool results)",
    "  2. Thinks (calls an LLM to decide what to do next)",
    "  3. Acts (calls a tool, searches the web, writes a file)",
    "  4. Loops — repeating steps 2–3 until it has a final answer.",
    "",
    "Unlike a simple chatbot (one call → one answer), an agent has dynamic,",
    "multi-step control flow.  The LLM itself decides the next step.",
])

add_concept_box("What is LangGraph?", [
    "LangGraph is a Python library that lets you build agent workflows as directed graphs.",
    "  • Nodes  = processing steps (Python functions)",
    "  • Edges  = connections between nodes (fixed or conditional)",
    "  • State  = a shared data structure that flows through the graph",
    "",
    "Think of it as a flowchart where nodes are boxes and edges are arrows.",
    "The LLM sits inside one of those boxes and decides which arrow to follow next.",
])

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Step 1 — Simple Chatbot  (step1_simple_chatbot.py)", 1)

add_heading("What We Build", 2)
add_body(
    "The most minimal LangGraph application: a single node that calls the LLM once "
    "and returns the answer. No tools, no memory, no loops."
)
add_code_block(["Graph flow:  START  →  chatbot  →  END"])

doc.add_paragraph()
add_heading("Core LangGraph Concepts Introduced Here", 2)

add_concept_box("1. State — The data container", [
    "State is a TypedDict (a typed Python dictionary).",
    "It carries data between every node in the graph.",
    "",
    "  class State(TypedDict):",
    "      messages: Annotated[list, add_messages]",
    "",
    "Why Annotated[list, add_messages]?",
    "  'add_messages' is a REDUCER — instead of overwriting the message list,",
    "  it APPENDS new messages to it.  Without this, every node would erase",
    "  the previous messages.",
])

add_concept_box("2. Node — A processing step", [
    "A node is just a Python function:",
    "  • Input  : the current State dict",
    "  • Output : a dict containing only the keys you want to update",
    "",
    "  def chatbot(state: State):",
    "      response = llm.invoke(state['messages'])",
    "      return {'messages': [response]}",
    "",
    "The function NAME becomes the node's label inside the graph.",
])

add_concept_box("3. Edge — A connection between nodes", [
    "Edges define the order of execution.",
    "  graph_builder.add_edge(START, 'chatbot')   # entry point",
    "  graph_builder.add_edge('chatbot', END)     # exit point",
    "",
    "START and END are special built-in sentinels provided by LangGraph.",
])

add_concept_box("4. Graph — The compiled workflow", [
    "  graph_builder = StateGraph(State)    # create builder",
    "  graph_builder.add_node(...)          # register nodes",
    "  graph_builder.add_edge(...)          # wire them up",
    "  graph = graph_builder.compile()      # produce a runnable graph",
    "",
    "After compile(), call graph.invoke({'messages': [...]}) to run it.",
])

doc.add_paragraph()
add_heading("Key Limitation: No Memory", 2)
add_body(
    "Each call to graph.invoke() is completely independent. The chatbot has no idea "
    "what was said in previous calls. We deliberately demonstrate this in Test 3 — "
    "when asked 'What did I just ask you?', the bot cannot answer. "
    "We fix this in Step 2."
)

doc.add_paragraph()
add_heading("Code Walkthrough", 2)
add_numbered("Import LangGraph, LangChain-OpenAI, and typing utilities.")
add_numbered("Define State with an add_messages reducer.")
add_numbered("Create an OpenAI LLM with temperature=0 (deterministic answers).")
add_numbered("Write the chatbot() node function.")
add_numbered("Build the graph: add node → add edges → compile.")
add_numbered("Invoke the graph 3 times to test basic Q&A and the no-memory behaviour.")

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Step 2 — Research Agent: Tools + ReAct Loop + Memory  (step2_research_agent.py)", 1)

add_heading("What We Build", 2)
add_body(
    "A fully functional research agent that can search the web and Wikipedia, "
    "loop until it has enough information, and remember previous messages using a checkpointer."
)
add_code_block([
    "Graph flow:",
    "  START → agent ──(has tool calls?)──► tools → (back to agent)",
    "                ──(no tool calls?)──► END",
])

doc.add_paragraph()
add_heading("New Concepts Introduced", 2)

add_concept_box("Tools — What the agent can DO", [
    "A tool is a Python function the LLM can call by name.",
    "LangChain provides ready-made tools:",
    "",
    "  tavily_search = TavilySearchResults(max_results=3)",
    "  wikipedia     = WikipediaQueryRun(...)",
    "  tools         = [tavily_search, wikipedia]",
    "",
    "  llm_with_tools = llm.bind_tools(tools)",
    "",
    "bind_tools() sends the tool schemas to the LLM so it knows they exist.",
    "The LLM can now output 'tool_calls' in its response — structured JSON",
    "specifying which tool to call and with what arguments.",
])

add_concept_box("ReAct Loop — Reason + Act cycle", [
    "ReAct (Reasoning + Acting) is the dominant pattern for agents:",
    "  1. Reason : LLM reads all messages, decides what to do",
    "  2. Act    : If it needs info, it outputs tool_calls",
    "  3. Observe: ToolNode executes the tools, adds results to messages",
    "  4. Repeat : LLM sees the results and decides again",
    "  5. Answer : When LLM has enough info, it outputs plain text (no tool_calls)",
    "",
    "This loop is implemented with a CONDITIONAL EDGE.",
])

add_concept_box("Conditional Edge — Dynamic routing", [
    "A conditional edge calls a Python function to choose the next node:",
    "",
    "  def should_continue(state) -> str:",
    "      if state['messages'][-1].tool_calls:",
    "          return 'tools'   # keep looping",
    "      return 'end'         # we are done",
    "",
    "  graph_builder.add_conditional_edges(",
    "      'agent',",
    "      should_continue,",
    "      {'tools': 'tools', 'end': END},",
    "  )",
    "",
    "This is what makes it an AGENT (dynamic) vs a CHAIN (fixed).",
])

add_concept_box("ToolNode — Automatic tool executor", [
    "LangGraph's built-in ToolNode handles tool execution automatically:",
    "  1. Reads tool_calls from the last AIMessage",
    "  2. Calls each tool with the provided arguments",
    "  3. Returns ToolMessage objects containing the results",
    "",
    "  tool_node = ToolNode(tools=tools)",
    "",
    "No manual tool dispatch code needed.",
])

add_concept_box("Memory (Checkpointer) — Persistent chat history", [
    "MemorySaver stores the graph state (all messages) between invocations.",
    "A thread_id groups messages into a single conversation.",
    "",
    "  memory = MemorySaver()",
    "  graph  = graph_builder.compile(checkpointer=memory)",
    "",
    "  config = {'configurable': {'thread_id': 'my-session'}}",
    "  graph.invoke({...}, config=config)",
    "",
    "Same thread_id → agent remembers previous messages.",
    "Different thread_id → fresh conversation, no memory.",
])

add_concept_box("System Prompt — Giving the agent its role", [
    "A SystemMessage placed at the start of the message list defines:",
    "  • The agent's identity ('You are a Research Assistant…')",
    "  • Which tool to use in which situation",
    "  • The expected output format",
    "",
    "We add it inside the agent() node, checking first that it is not",
    "already present (important when memory loads a past conversation).",
])

doc.add_paragraph()
add_heading("Code Walkthrough", 2)
add_numbered("Define two tools: Tavily web search and Wikipedia lookup.")
add_numbered("Create AgentState (same as Step 1 State).")
add_numbered("Create the LLM and call bind_tools() to enable tool use.")
add_numbered("Write the agent() node: prepend system prompt, call LLM.")
add_numbered("Create tool_node with ToolNode(tools=tools).")
add_numbered("Write should_continue() routing function.")
add_numbered("Build graph with conditional edge + back-edge from tools → agent.")
add_numbered("Attach MemorySaver and compile.")
add_numbered("Test with three scenarios: basic query, follow-up (tests memory), new thread.")

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# STEP 3
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Step 3 — Interactive Session with Streaming  (step3_interactive_session.py)", 1)

add_heading("What We Build", 2)
add_body(
    "The same research agent as Step 2, but wrapped in an interactive terminal chat loop. "
    "You can hold a real conversation with the agent and watch it reason step by step."
)

doc.add_paragraph()
add_heading("New Concepts Introduced", 2)

add_concept_box("Streaming — Watch the agent think in real time", [
    "Instead of graph.invoke() (waits for full completion),",
    "use graph.stream() to receive events as they happen:",
    "",
    "  for event in graph.stream(",
    "      {'messages': [HumanMessage(content=user_input)]},",
    "      config=config,",
    "      stream_mode='values',",
    "  ):",
    "      last_msg = event['messages'][-1]",
    "      # inspect last_msg here ...",
    "",
    "Each event is a snapshot of the full state after one node completes.",
    "You can print tool calls and results as they arrive.",
])

add_concept_box("Message Type Inspection", [
    "How to tell what kind of message just arrived:",
    "",
    "  has_tool_calls = hasattr(msg, 'tool_calls') and msg.tool_calls",
    "  is_tool_result = hasattr(msg, 'type') and msg.type == 'tool'",
    "",
    "  • AIMessage with tool_calls → the LLM decided to call a tool",
    "  • ToolMessage              → a tool just returned its result",
    "  • AIMessage without tool_calls → the final answer",
])

add_concept_box("session Commands (UX Pattern)", [
    "The interactive loop handles special commands:",
    "  'quit' / 'exit' — end the session and print summary stats",
    "  'new'           — start a fresh conversation by generating a new",
    "                    UUID-based thread_id (clears memory)",
    "  'history'       — call graph.get_state(config) to read current",
    "                    message count from the checkpointer",
    "",
    "  state = graph.get_state(config)",
    "  msg_count = len(state.values.get('messages', []))",
])

add_concept_box("API Key Validation on Startup", [
    "Always validate required credentials before the user types anything:",
    "",
    "  def check_api_keys():",
    "      missing = []",
    "      if not os.getenv('OPENAI_API_KEY'): missing.append(...)",
    "      if not os.getenv('TAVILY_API_KEY'): missing.append(...)",
    "      if missing:",
    "          print('[ERROR] Missing API keys:', missing)",
    "          sys.exit(1)",
    "",
    "Fail fast with a clear error message rather than crashing mid-conversation.",
])

doc.add_paragraph()
add_heading("Code Walkthrough", 2)
add_numbered("check_api_keys() — validate .env before any LangGraph code runs.")
add_numbered("Build the same graph as Step 2 (tools, ReAct loop, MemorySaver).")
add_numbered("run_research_session() — the interactive loop:")
add_bullet("Read user input with input().", level=1)
add_bullet("Handle 'quit', 'new', 'history' commands.", level=1)
add_bullet("Call graph.stream() and print tool calls + results live.", level=1)
add_bullet("After the loop ends, print the final assistant message.", level=1)

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# STEP 4
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Step 4 — Extensions  (step4_extensions.py)", 1)

add_heading("What We Build", 2)
add_body(
    "Four independent, mix-and-match extensions that make the agent production-ready. "
    "Students are expected to implement at least two of these in their assignment."
)

doc.add_paragraph()
add_heading("Extension A — Custom Tools with @tool Decorator", 2)

add_concept_box("How to Create a Custom Tool", [
    "Any Python function decorated with @tool becomes an LLM-callable tool.",
    "The DOCSTRING is the tool description the LLM reads to decide when to use it.",
    "TYPE HINTS become the parameter schema (the LLM fills these in).",
    "",
    "  from langchain_core.tools import tool",
    "",
    "  @tool",
    "  def save_report(content: str, filename: str) -> str:",
    "      '''Save a research report to a markdown file.'''",
    "      ...",
    "",
    "  @tool",
    "  def calculate(expression: str) -> str:",
    "      '''Evaluate a mathematical expression.'''",
    "      result = eval(expression, {'__builtins__': {}, 'math': math})",
    "      return f'{expression} = {result}'",
    "",
    "Security note: never use bare eval(). Restrict builtins as shown above.",
])

doc.add_paragraph()
add_heading("Extension B — Maximum Iteration Safety", 2)

add_concept_box("Preventing Infinite Loops", [
    "In production, agents can get stuck in tool loops.  Add a counter to State:",
    "",
    "  class AgentStateWithCounter(TypedDict):",
    "      messages:        Annotated[list, add_messages]",
    "      iteration_count: int",
    "",
    "  MAX_ITERATIONS = 10",
    "",
    "  def should_continue_with_safety(state) -> str:",
    "      if state.get('iteration_count', 0) >= MAX_ITERATIONS:",
    "          return 'end'   # force-stop",
    "      if state['messages'][-1].tool_calls:",
    "          return 'tools'",
    "      return 'end'",
    "",
    "Increment the counter inside the agent node on every call.",
    "This is CRITICAL for any deployed agent.",
])

doc.add_paragraph()
add_heading("Extension C — Structured Output with Pydantic", 2)

add_concept_box("Forcing the LLM to Return Typed JSON", [
    "Define a Pydantic model for the expected output:",
    "",
    "  class ResearchReport(BaseModel):",
    "      topic:               str",
    "      key_findings:        List[str]",
    "      background:          str",
    "      recent_developments: str",
    "      sources:             List[str]",
    "      confidence:          str",
    "",
    "  structured_llm = llm.with_structured_output(ResearchReport)",
    "  report = structured_llm.invoke('Research quantum computing...')",
    "  print(report.topic, report.key_findings)",
    "",
    "The LLM is forced to produce valid JSON that matches the schema.",
    "Note: structured output and tool-calling cannot be used in the SAME",
    "LLM call — use structured output in a final formatting step after",
    "all research is done.",
])

doc.add_paragraph()
add_heading("Extension D — Human-in-the-Loop (HITL)", 2)

add_concept_box("Keeping a Human in the Decision Loop", [
    "For sensitive actions (saving files, sending emails, executing code),",
    "pause and ask the user before proceeding.",
    "",
    "Approach used here: instruct the LLM via the system prompt:",
    "  'Before saving a file, confirm with the user first.'",
    "",
    "More advanced HITL uses LangGraph's interrupt mechanism:",
    "  graph_builder.compile(checkpointer=memory, interrupt_before=['tools'])",
    "This pauses the graph before the tools node runs and waits for",
    "human approval before continuing.",
    "",
    "HITL is essential for:",
    "  • Irreversible actions (deleting data, sending messages)",
    "  • High-stakes decisions (financial transactions)",
    "  • Anything that needs audit trails",
])

doc.add_paragraph()
add_heading("The build_extended_agent() Function", 2)
add_body(
    "Step 4 combines all extensions into one agent: all four tools, "
    "iteration safety, and a comprehensive system prompt. "
    "The function returns a compiled graph so it can be reused in tests or a UI."
)

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# ARCHITECTURE SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Architecture Summary", 1)

add_concept_box("LangGraph Building Blocks — Quick Reference", [
    "StateGraph(State)               Create a new graph with this State schema",
    "add_node('name', fn)            Register a node (function) in the graph",
    "add_edge(A, B)                  Fixed edge: always go from A to B",
    "add_conditional_edges(A, fn, M) Dynamic edge: fn(state) picks the next node",
    "compile(checkpointer=mem)       Produce a runnable graph with optional memory",
    "graph.invoke(input, config)     Run the graph to completion",
    "graph.stream(input, config)     Run the graph, yielding state after each node",
    "graph.get_state(config)         Inspect the saved state for a thread",
    "ToolNode(tools)                 Built-in node that executes tool_calls",
    "MemorySaver()                   In-memory checkpointer for chat history",
])

add_concept_box("Progression Across Steps", [
    "Step 1: State + Node + Edge + Graph              (core primitives)",
    "Step 2: + Tools + ReAct Loop + Memory            (real agent)",
    "Step 3: + Streaming + Interactive UI             (usable product)",
    "Step 4: + Custom Tools + Safety + Structured Output + HITL  (production-ready)",
])

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# ASSIGNMENT
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Assignment — Extend the Research Agent", 1)

add_body("Task:", bold=True)
add_body(
    "Starting from step3_interactive_session.py, add at least TWO of the "
    "extensions from Step 4 to create your own enhanced research agent."
)

doc.add_paragraph()
add_body("Requirements:", bold=True)
add_numbered("Implement Extension B (iteration safety) — this is mandatory.")
add_numbered("Choose and implement at least one more extension from A, C, or D.")
add_numbered("Write a brief README explaining what each extension does and why you chose it.")
add_numbered("Demonstrate your agent working end-to-end in a short screen recording or screenshot.")

doc.add_paragraph()
add_body("Bonus challenges:", bold=True)
add_bullet("Add a third tool of your own design (e.g., a calculator, a weather API, a file reader).")
add_bullet("Implement full LangGraph interrupt-based HITL (not just prompt-based).")
add_bullet("Add a structured output formatting step at the end of the ReAct loop.")

doc.add_paragraph()
divider()
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# QUICK REFERENCE
# ══════════════════════════════════════════════════════════════════════════════
add_heading("Quick Reference — Key Terms", 1)

terms = [
    ("LangGraph",         "A Python library for building LLM workflows as directed graphs."),
    ("State",             "TypedDict that carries data between nodes. Shared across the entire graph."),
    ("Node",              "A Python function: reads state → does work → returns partial state update."),
    ("Edge",              "A directed connection between two nodes. Can be fixed or conditional."),
    ("Conditional Edge",  "Calls a routing function to decide which node to go to next."),
    ("ToolNode",          "Built-in LangGraph node that auto-executes tool_calls from the last AIMessage."),
    ("MemorySaver",       "In-memory checkpointer. Stores full graph state between invocations."),
    ("thread_id",         "Groups messages into one conversation. Change it to start a new conversation."),
    ("ReAct",             "Reason + Act loop: LLM reasons, calls tools, observes results, repeats."),
    ("bind_tools()",      "Attaches tool schemas to the LLM so it knows which tools are available."),
    ("add_messages",      "LangGraph reducer: appends new messages instead of replacing the list."),
    ("@tool",             "LangChain decorator that turns any Python function into an LLM-callable tool."),
    ("Structured Output", "with_structured_output(Model) forces the LLM to return typed JSON."),
    ("HITL",              "Human-in-the-Loop: pause agent execution and wait for human approval."),
]

tbl = doc.add_table(rows=1, cols=2)
tbl.style = "Table Grid"
hdr = tbl.rows[0].cells
shade_cell(hdr[0], "1A5376")
shade_cell(hdr[1], "1A5376")
for cell, text in zip(hdr, ["Term", "Definition"]):
    p = cell.paragraphs[0]
    p.clear()
    r = p.add_run(text)
    r.font.bold = True
    r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    r.font.size = Pt(10.5)

for i, (term, defn) in enumerate(terms):
    row   = tbl.add_row().cells
    color = "F2F8FC" if i % 2 == 0 else "FFFFFF"
    shade_cell(row[0], color)
    shade_cell(row[1], color)
    r0 = row[0].paragraphs[0].add_run(term)
    r0.font.bold = True
    r0.font.size = Pt(10)
    r1 = row[1].paragraphs[0].add_run(defn)
    r1.font.size = Pt(10)

doc.add_paragraph()

# ── Save ──────────────────────────────────────────────────────────────────────
output_path = "Agentic_AI_Lecture_Notes.docx"
doc.save(output_path)
print(f"Done! Saved to: {output_path}")
