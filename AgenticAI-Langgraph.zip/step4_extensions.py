"""
==========================================================================
  STEP 4: Extensions — Take the Research Agent Further
==========================================================================

This file demonstrates several extensions students can add to their
research agent for the assignment:

  Extension A: Custom tool — save research reports to a file
  Extension B: Maximum iteration safety — prevent infinite loops
  Extension C: Structured output — force JSON output with Pydantic
  Extension D: Human-in-the-loop — ask for confirmation before actions

Each extension is self-contained and can be mixed and matched.

Run this file:
  python step4_extensions.py
==========================================================================
"""

import os
import json
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

from typing import Annotated, Optional
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver

from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.tools import tool

from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper


# =====================================================================
# EXTENSION A: Custom Tools — Save Reports to File
# =====================================================================
# Any Python function decorated with @tool becomes a LangChain tool.
# The docstring becomes the tool description (what the LLM reads).
# Type hints become the parameter schema.

@tool
def save_report(content: str, filename: str) -> str:
    """Save a research report to a markdown (.md) file.

    Use this tool when the user asks you to save, export, or write
    your research findings to a file. The content should be well-formatted
    markdown text.

    Args:
        content: The full research report content in markdown format.
        filename: The filename to save (without extension, .md is added).
    """
    # Sanitize filename
    safe_name = "".join(c for c in filename if c.isalnum() or c in "-_ ").strip()
    if not safe_name:
        safe_name = f"research_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    filepath = f"{safe_name}.md"

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)

    return f"Report saved successfully to: {filepath} ({len(content):,} characters)"


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression and return the result.

    Use this for any calculations: arithmetic, percentages, unit conversions, etc.
    The expression should be valid Python math.

    Args:
        expression: A mathematical expression (e.g., "1024 * 768", "15 / 100 * 250").
    """
    try:
        # Use eval with restricted builtins for safety
        allowed = {"__builtins__": {}}
        import math
        allowed["math"] = math
        result = eval(expression, allowed)
        return f"{expression} = {result}"
    except Exception as e:
        return f"Error evaluating '{expression}': {e}"


print("Extension A: Custom tools (save_report, calculate) defined.")


# =====================================================================
# EXTENSION B: Maximum Iteration Safety
# =====================================================================
# Prevent infinite loops by counting iterations and stopping the agent
# if it exceeds a limit. This is CRITICAL for production agents.

MAX_ITERATIONS = 10  # Safety limit

class AgentStateWithCounter(TypedDict):
    messages: Annotated[list, add_messages]
    iteration_count: int  # Track how many agent->tool loops we've done


def should_continue_with_safety(state: AgentStateWithCounter) -> str:
    """Route with safety check: stop if too many iterations."""
    last_message = state["messages"][-1]
    iteration_count = state.get("iteration_count", 0)

    # Safety check: prevent infinite loops
    if iteration_count >= MAX_ITERATIONS:
        print(f"\n  [SAFETY] Max iterations ({MAX_ITERATIONS}) reached. Stopping agent.")
        return "end"

    # Normal routing
    if last_message.tool_calls:
        return "tools"

    return "end"


print("Extension B: Max iteration safety defined.")


# =====================================================================
# EXTENSION C: Structured Output — Force JSON with Pydantic
# =====================================================================
# Instead of free-text answers, force the agent to return a specific
# JSON schema using Pydantic models.

from pydantic import BaseModel, Field
from typing import List


class ResearchReport(BaseModel):
    """Structured research report output."""
    topic: str = Field(description="The research topic")
    key_findings: List[str] = Field(description="Top 3-5 key findings as bullet points")
    background: str = Field(description="Background context paragraph")
    recent_developments: str = Field(description="Recent developments paragraph")
    sources: List[str] = Field(description="List of sources consulted")
    confidence: str = Field(
        description="Confidence level: 'high', 'medium', or 'low'",
    )


# To use structured output, bind the schema to the LLM:
# llm_structured = llm.with_structured_output(ResearchReport)
# This forces the LLM to output ONLY valid ResearchReport JSON.
# Note: structured output can't be combined with tool calling in the
# same call, so use it in a final "formatting" step after research.

print("Extension C: Structured output schema (ResearchReport) defined.")


# =====================================================================
# EXTENSION D: Human-in-the-Loop
# =====================================================================
# For sensitive actions, pause and ask the user for confirmation.

def agent_with_hitl(state: AgentStateWithCounter):
    """Agent node with human-in-the-loop for sensitive tools."""
    messages = state["messages"]

    system_msg = SystemMessage(content="""You are a Research Assistant agent.
You have access to web search, Wikipedia, a calculator, and a file saver.

IMPORTANT: Before saving a file, always confirm with the user first by
saying what you plan to save and asking if they want you to proceed.

Guidelines:
- Search the web and Wikipedia for information
- Use the calculator for any math
- Save reports when asked
- Always cite sources""")

    if not any(isinstance(m, SystemMessage) for m in messages):
        messages = [system_msg] + messages

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    all_tools = [tavily_search, wikipedia, calculate, save_report]
    llm_with_all_tools = llm.bind_tools(all_tools)

    response = llm_with_all_tools.invoke(messages)

    # Track iterations
    iteration_count = state.get("iteration_count", 0) + 1

    return {"messages": [response], "iteration_count": iteration_count}


print("Extension D: Human-in-the-loop agent node defined.")


# =====================================================================
# BUILD THE EXTENDED AGENT
# =====================================================================
def build_extended_agent():
    """Build an agent with all extensions enabled."""

    # All tools (including custom ones)
    all_tools = [tavily_search, wikipedia, calculate, save_report]

    # LLM with all tools
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    llm_with_all_tools = llm.bind_tools(all_tools)

    # System prompt referencing all tools
    system_prompt = """You are a thorough Research Assistant agent with extended
capabilities. You can search the web, look up Wikipedia, do calculations,
and save reports to files.

TOOLS:
- tavily_search_results_json: Search the web for current information
- wikipedia: Look up background knowledge on Wikipedia
- calculate: Evaluate math expressions (percentages, conversions, etc.)
- save_report: Save your research to a markdown file

GUIDELINES:
- Always search before answering — use multiple sources
- Use the calculator for any numbers or comparisons
- When asked to save a report, compile your findings and use save_report
- Cross-reference information from multiple sources
- Cite your sources in every answer
- Never fabricate information

OUTPUT FORMAT:
1. **Key Findings** (bullet points)
2. **Background Context**
3. **Recent Developments**
4. **Sources**"""

    # Agent node with iteration tracking
    def agent_node(state: AgentStateWithCounter):
        messages = state["messages"]
        if not any(isinstance(m, SystemMessage) for m in messages):
            messages = [SystemMessage(content=system_prompt)] + messages
        response = llm_with_all_tools.invoke(messages)
        iteration_count = state.get("iteration_count", 0) + 1
        return {"messages": [response], "iteration_count": iteration_count}

    # Tool node with all tools
    tool_node = ToolNode(tools=all_tools)

    # Build graph
    graph_builder = StateGraph(AgentStateWithCounter)
    graph_builder.add_node("agent", agent_node)
    graph_builder.add_node("tools", tool_node)
    graph_builder.add_edge(START, "agent")
    graph_builder.add_conditional_edges(
        "agent",
        should_continue_with_safety,
        {"tools": "tools", "end": END},
    )
    graph_builder.add_edge("tools", "agent")

    memory = MemorySaver()
    return graph_builder.compile(checkpointer=memory)


# =====================================================================
# DEMO: Run the Extended Agent
# =====================================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  Extended Research Agent Demo")
    print("  (with custom tools, safety limits, and structured output)")
    print("=" * 60)

    graph = build_extended_agent()
    config = {"configurable": {"thread_id": "extended-demo-1"}}

    # --- Demo 1: Research with calculator ---
    print("\n--- Demo 1: Research with Calculation ---")
    print("Query: What is the GDP of India and Japan? Calculate the difference.\n")

    for event in graph.stream(
        {"messages": [HumanMessage(
            content="What is the current GDP of India and Japan? Calculate the percentage difference."
        )]},
        config=config,
        stream_mode="values",
    ):
        last_msg = event["messages"][-1]
        if hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
            for tc in last_msg.tool_calls:
                print(f"  -> Calling {tc['name']}: {tc['args']}")
        elif hasattr(last_msg, "type") and last_msg.type == "tool":
            print(f"     Result: {last_msg.content[:100]}...")

    print(f"\nAnswer:\n{event['messages'][-1].content}")

    # --- Demo 2: Save a report ---
    print("\n\n--- Demo 2: Save Research to File ---")
    print("Query: Save that research as a report.\n")

    for event in graph.stream(
        {"messages": [HumanMessage(
            content="Please save the GDP comparison research we just did as a report called 'gdp_comparison'"
        )]},
        config=config,
        stream_mode="values",
    ):
        last_msg = event["messages"][-1]
        if hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
            for tc in last_msg.tool_calls:
                print(f"  -> Calling {tc['name']}: {json.dumps(tc['args'])[:100]}...")
        elif hasattr(last_msg, "type") and last_msg.type == "tool":
            print(f"     Result: {last_msg.content}")

    print(f"\nAnswer:\n{event['messages'][-1].content}")

    # --- Demo 3: Structured output ---
    print("\n\n--- Demo 3: Structured Output (Standalone) ---")
    print("Forcing LLM to output a ResearchReport JSON schema...\n")

    structured_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0).with_structured_output(ResearchReport)

    report = structured_llm.invoke(
        "Create a research report about the current state of quantum computing. "
        "Use your knowledge to fill in all fields."
    )

    print(f"  topic:               {report.topic}")
    print(f"  key_findings:        {report.key_findings[:2]}...")
    print(f"  background:          {report.background[:100]}...")
    print(f"  recent_developments: {report.recent_developments[:100]}...")
    print(f"  sources:             {report.sources[:2]}...")
    print(f"  confidence:          {report.confidence}")

    print("\n" + "=" * 60)
    print("  All extension demos complete!")
    print("=" * 60)
    print("\nAssignment: Add at least TWO of these extensions to your agent.")
    print("See the Session 2 student material for full requirements.")
