# Conda (Anaconda / Miniconda)

Conda is an open-source package management system and environment management system that runs on Windows, macOS, and Linux.

## 1. Installation

Install [Anaconda](https://www.anaconda.com/download) or [Miniconda](https://docs.anaconda.com/free/miniconda/) (a minimal installer for conda).

## 2. Create an Environment

To create a new environment:

```bash
# Create an environment named 'myenv' with Python 3.11
conda create --name myenv python=3.11
```

Confirm the installation when prompted.

## 3. Activate the Environment

```bash
conda activate myenv
```

## 4. Install Packages

You can install packages from the Anaconda repository or other channels like conda-forge.

```bash
# Install numpy
conda install numpy

# Install from conda-forge
conda install -c conda-forge pandas
```

You can also use `pip` inside a conda environment:

```bash
pip install requests
```

## 5. Export and Create from File

To export your environment to a YAML file:

```bash
conda env export > environment.yml
```

To create an environment from a YAML file:

```bash
conda env create -f environment.yml --prefix my_env
```

## 6. Deactivate

```bash
conda deactivate
```
