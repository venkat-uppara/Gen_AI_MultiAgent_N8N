# Python Built-in `venv`

The `venv` module provides support for creating lightweight "virtual environments" with their own site directories, optionally isolated from system site directories.

## 1. Create a Virtual Environment

Open your terminal or command prompt and navigate to your project directory.

Run the following command:

```bash
# Windows
python -m venv .venv

# macOS / Linux
python3 -m venv .venv
```

This creates a directory named `.venv` (you can choose any name, but `.venv` or `venv` is standard) in your project folder.

## 2. Activate the Virtual Environment

Before you can start installing or using packages in your virtual environment, you’ll need to activate it.

```bash
# Windows (Command Prompt)
.venv\Scripts\activate.bat

# Windows (PowerShell)
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate
```

After activation, your command prompt will change to show the name of the activated environment.

## 3. Install Packages

Once activated, you can install packages using `pip`.

```bash
pip install requests
```

To save your dependencies:

```bash
pip freeze > requirements.txt
```

To install from requirements:

```bash
pip install -r requirements.txt
```

## 4. Deactivate

To leave the virtual environment, simply run:

```bash
deactivate
```
