# `uv` - An Extremely Fast Python Package Installer

`uv` is a Python package installer and resolver, written in Rust. It is designed as a drop-in replacement for pip and pip-tools, but significantly faster.

## 1. Installation

First, install `uv`.

```bash
# Windows (PowerShell)
irm https://astral.sh/uv/install.ps1 | iex

# macOS / Linux
curl -lsSf https://astral.sh/uv/install.sh | sh

# Via pip
pip install uv
```

## 2. Create a Virtual Environment

`uv` can create virtual environments much faster than the standard `venv` module.

```bash
uv venv
```

By default, this creates a `.venv` directory. You can specify a different name or python version:

```bash
# Create with specific Python version
uv venv --python 3.12
```

## 3. Activate the Virtual Environment

Activation is the same as with standard `venv`.

```bash
# Windows (PowerShell)
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate
```

## 4. Install Packages

`uv` is a drop-in replacement for `pip`.

```bash
# Install a package
uv pip install requests

# Install from requirements.txt
uv pip install -r requirements.txt
```

`uv` also has a sync command to sync the environment with a `requirements.txt` file, ensuring exact reproducibility:

```bash
uv pip sync requirements.txt
```

## 5. Deactivate

```bash
deactivate
```
