# Poetry - Dependency Management and Packaging

Poetry is a tool for dependency management and packaging in Python. It allows you to declare the libraries your project depends on and it will manage (install/update) them for you.

## 1. Installation

It is recommended to install Poetry using the official installer.

```bash
# Windows (PowerShell)
(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -

# macOS / Linux
curl -sSL https://install.python-poetry.org | python3 -
```

## 2. Initialize a Project

To creating a new project with Poetry:

```bash
poetry new my-project
```

To initialize Poetry in an existing project:

```bash
cd my-project
poetry init
```

This will guide you through creating a `pyproject.toml` file.

## 3. Create and Activate Virtual Environment

Poetry automatically manages virtual environments.

**Tip:** To create the virtual environment inside your project directory (like `venv`), run:

```bash
poetry config virtualenvs.in-project true
```

To create/activate the environment:

```bash
poetry shell
```

If the environment doesn't exist, Poetry will create one.

To run a command without activating the shell:

```bash
poetry run python app.py
```

## 4. Install Packages

To add a package:

```bash
poetry add requests
```

This updates `pyproject.toml` and allows `poetry.lock`.

To install all dependencies (e.g., after cloning a repo):


```bash
poetry config virtualenvs.in-project true
```

```bash
poetry install --no-cache
```

## 5. Deactivate

If you are in a `poetry shell`, simply type:

```bash
exit
```
